# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.
