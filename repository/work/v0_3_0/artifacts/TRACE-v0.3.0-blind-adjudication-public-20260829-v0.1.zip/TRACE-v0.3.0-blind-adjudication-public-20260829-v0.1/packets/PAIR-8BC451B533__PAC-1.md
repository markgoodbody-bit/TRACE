# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.

---

# Adjudication packet

Packet ID: `PAIR-8BC451B533`
Case ID: `PAC-1`

## Frozen case packet

CASE: Armoured Vehicles — the Ajax programme
CASE_ID: 6bd0b0cc9829fcdab2361ad9deb533b61446dbacaed7b9d9424f2773260fb731

SOURCE BASIS

Primary source: House of Commons Committee of Public Accounts, Seventh Report of Session 2022–23, “Armoured Vehicles: the Ajax programme”, published 3 June 2022.
Official report: https://publications.parliament.uk/pa/cm5803/cmselect/cmpubacc/259/report.html

This packet is a bounded factual digest of the Committee’s report. Committee conclusions and recommendations are identified as such and are not treated as a complete account of the programme, contract, technical evidence or later developments.

FACTUAL MATERIAL

Ajax is an armoured fighting-vehicle programme intended to provide the British Army with a digitally integrated surveillance and reconnaissance capability. The Ministry of Defence had a £5.5 billion firm-priced contract with General Dynamics Land Systems UK for the design, manufacture and initial in-service support of 589 vehicles in six variants.

The programme began in 2010. By December 2021 the Department had paid General Dynamics £3.2 billion; 324 hulls had been built, 143 vehicles assembled and tested, and the Department had received 26 Ajax vehicles plus training systems and some logistics support and spares. The expected in-service date had been extended and then missed again. At the time of the Committee’s June 2022 report, the Army had not received a deployable Ajax vehicle and the Department did not know when the system would enter service.

The Department and General Dynamics were in dispute over unresolved contractual, safety and technical issues. The Committee said the Department appeared reluctant to investigate alternatives if the contract failed, while the Army had planned operational compromises to manage delays.

The Committee found that the programme had accumulated excessive complexity. Although Ajax was based on a pre-existing vehicle, the Department specified roughly 1,200 capability requirements. The Department and supplier did not fully understand the complexity of the resulting approach and did not manage design changes effectively. A 2018 programme reset added complexity and the revised schedule was unrealistic. Demonstration and manufacturing overlapped, meaning production continued while technical and safety issues remained unresolved.

Noise and vibration became major safety concerns. The Committee reported that the Department acknowledged injuries to some soldiers and described the outcome as “unforgivable”. Defence Science and Technology Laboratory advisers had warned Defence Equipment & Support about potential compliance concerns in 2014, but as advisers they did not have authority to require action. Vibration concerns were raised in trials from late 2019 and injuries were reported from July 2020, but excessive noise and vibration were not reported to the programme’s senior responsible owner until September 2020.

A safety review led by David King concluded that collective failings had allowed activity to continue when it should have been stopped or paused until stronger controls were in place. The review made 20 recommendations. The Department introduced measures including noise and vibration working groups and a web-based reporting application; the Committee reported that incident and near-miss reporting had risen after the application was introduced. The Committee nevertheless said the flow of information from junior ranks to senior officers needed to become more thorough and transparent.

At the time of the report, proposed vehicle modifications intended to reduce noise and vibration were still being tested. It was unclear whether these changes would be sufficient or whether more fundamental redesign would be needed. The Department could not be confident that further technical or safety issues would not emerge.

The Committee recommended that the Department investigate alternative options to Ajax so that it could act quickly if the contract failed; improve management of major equipment programmes; simplify and strengthen safety processes and escalation; monitor the effectiveness of safety changes; and show how lessons from Ajax would be incorporated into future programmes.

INFORMATION NOT SUPPLIED IN THIS PACKET

The packet does not reproduce the contract, detailed engineering data, trial datasets, medical information about affected soldiers, legal positions in the dispute, the full King review, supplier evidence or later programme developments after June 2022. It does not establish the technical root cause of every noise or vibration issue, the final effectiveness of proposed modifications, whether contract termination would have produced better outcomes, or the exact military consequences of each delay.

REVIEW QUESTION

Using only the information in this packet, what should a person reviewing this situation understand before deciding what action, oversight, or follow-up is warranted?

---

## Response `RESPONSE-7769DD34CD`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1258
Blind main-answer words: 1075
Positive-gain-creditable words: 1075

### POSITIVE-GAIN-CREDITABLE TEXT

# Analysis: The Ajax Programme (as at June 2022)

## What the evidence in this packet actually supports

Everything here comes through one aperture: a parliamentary select committee report of June 2022, drawing on a safety review (the King review) and departmental information. Committee findings are reported and argued, not independently verified technical fact. That doesn't make them unreliable — select committees take evidence under formal procedure — but a reviewer should notice that the packet contains no contract text, no engineering data, no trial datasets, no medical evidence, and no supplier account. The dispute between the Department and General Dynamics is described only from the Committee's vantage point.

Within those limits, some things are well supported:

- **Money and output are out of proportion so far.** £3.2 billion of a £5.5 billion firm-priced contract paid; 26 vehicles delivered against 589 contracted; no deployable vehicle; no known in-service date as of June 2022. These are figures the Department itself supplied or did not contest.
- **The safety failure was real and acknowledged.** The Department itself described soldier injuries from noise and vibration as "unforgivable," and the King review found collective failings allowed work to continue that should have been paused. This is not contested in the packet.
- **The escalation path failed over a long period.** Specialist advisers flagged compliance concerns in 2014 but had no authority to act. Trial concerns from late 2019 and injuries from July 2020 did not reach the senior responsible owner until September 2020. That is roughly a year of lag between observable harm and senior visibility, and six years between the first advisory warning and senior escalation.
- **Complexity was self-inflicted.** Around 1,200 capability requirements were layered onto what was a pre-existing vehicle design; a 2018 reset added more complexity and produced a schedule the Committee judged unrealistic; production ran in parallel with unresolved technical and safety problems.

## What remains unknown — and should stay unknown

A reviewer should resist filling these in:

- **Technical root cause and fixability.** Whether the proposed noise and vibration modifications work was untested at the report date; whether fundamental redesign is needed is genuinely open. The packet cannot distinguish "fixable teething problem" from "structurally compromised design."
- **Whether cancellation or continuation is the better course.** The Committee itself stopped short of recommending termination; it recommended the Department prepare alternatives *in case* the contract fails. The packet contains no basis to judge legal exposure, sunk-cost recovery, or alternative procurement outcomes.
- **The cause of the escalation failure.** Silence at senior level between 2014–2020 is established; *why* is not. It could be filtering, suppressed reporting, contractual incentives, or organisational design. These imply different remedies. Note also that after a reporting app was introduced, incident and near-miss reporting *rose* — which could mean better visibility, worse underlying conditions, or both. Rising reports are not evidence of either.
- **Whether the safety reforms work.** Working groups and a reporting app exist; their effectiveness was unproven at report date. The Committee explicitly said junior-to-senior information flow still needed to improve. A check existing is not a check working.
- **Anything after June 2022.** The programme may since have recovered, stalled further, or been restructured. Any decision made now on this packet alone would rest on a snapshot at least three years old, on a programme whose defining feature is that its status keeps changing.

## The structural picture

Stripped of detail, the failure pattern is this: a bounded, firm-priced contract created strong incentives for both parties to keep the programme moving; safety-critical signals existed at working level but had no route with authority attached to them (advisers could warn but not require); production and demonstration overlapped, so unresolved problems were baked into physical hulls while money continued to flow; and each schedule slip was met with re-planning rather than re-examination of whether the programme as specified was deliverable. The injury reports are not a separate failure from the schedule failure — they are what the schedule failure looked like at working level.

Two timing observations matter for any decision:

1. **The correction window has been narrowing for years.** Each year of delay, 324 built hulls embody a design whose final form is undecided. Modifications applied later to already-built vehicles are harder and costlier than design corrections before manufacture. This is hardening, not yet irreversibility — but the packet gives no boundary for when retrofit ceases to be viable, and no evidence the Department has defined one.
2. **Every further payment reduces the room to manoeuvre.** With £3.2bn of £5.5bn already paid and deliveries at under 5% of contracted vehicles, the remaining leverage is concentrated in whatever the contract actually provides — which this packet does not contain.

## What a reviewer should understand before deciding anything

**Factual/structural:**

- The decision is not "Ajax versus a fresh start" in the abstract. It is Ajax-with-unknown-fixability versus alternatives that have never been investigated, under a contract whose terms are not in evidence here. The single most consequential gap is that the Department had not examined alternatives — meaning any current choice would be made without a comparison basis.
- The safety question and the commercial question are entangled but not identical. Modifications might make vehicles safe without making the programme good value; the contract might be terminated without resolving what capability replaces Ajax. Conflating them produces bad decisions in both directions.
- The programme's own reporting mechanisms have repeatedly produced optimistic schedules. Any forward date supplied by the programme should be treated as a claim requiring independent scrutiny, not a fact.
- Currentness: this packet is a June 2022 snapshot. Before any present-day decision, the first task is establishing what has changed — vehicle status, modification results, dispute position, injuries since, and whether alternatives were ever scoped.

**What this does not settle** (kept separate, as instructed): whether the contract should be cancelled, who is blameworthy, whether the injuries were legally actionable, or what oversight intensity is proportionate. Those require the contract, the medical and legal material, and a value judgement about acceptable cost and risk that this packet does not supply.

The packet is sufficient to support a narrower conclusion: that decisions about this programme should not be made on programme-supplied information alone, that an alternatives investigation is a prerequisite to any credible continue/stop choice, and that the escalation failure — not only the engineering failure — is the thing that needs verified repair before resumed trials could be justified.

---

---

## Response `RESPONSE-65EF305BCF`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1230
Blind main-answer words: 1230
Positive-gain-creditable words: 1200

### POSITIVE-GAIN-CREDITABLE TEXT

# Ajax Programme — Decision-Review Analysis

**Scope note:** Everything below derives solely from the June 2022 Public Accounts Committee digest. Nothing here reflects developments after that date, and Committee conclusions are treated as findings of one body, not a complete account.

---

## 1. What is supported by the packet

**Programme state (as of June 2022):**
- A £5.5bn firm-priced contract with General Dynamics Land Systems UK for 589 vehicles in six variants; programme began 2010.
- £3.2bn paid; 324 hulls built, 143 vehicles assembled and tested, 26 Ajax vehicles delivered plus training systems and some spares.
- No deployable vehicle in Army hands; in-service date extended, then missed again; the Department did not know when entry into service would occur.
- Department and supplier were in dispute over unresolved contractual, safety and technical issues.

**Structural/management findings (Committee's):**
- ~1,200 capability requirements specified on a platform that was based on a pre-existing vehicle; complexity was not fully understood by either party; design changes were not managed effectively.
- A 2018 reset added complexity and produced an unrealistic schedule.
- Demonstration and manufacturing overlapped — production continued while technical and safety issues remained unresolved.

**Safety findings:**
- Noise and vibration caused injuries to some soldiers; the Department called the outcome "unforgivable."
- Advisers (Dstl) flagged potential compliance concerns in 2014 but lacked authority to compel action.
- Vibration concerns surfaced in trials from late 2019; injuries reported from July 2020; the senior responsible owner was not informed until September 2020.
- The King review found collective failings allowed activity to continue that should have been stopped or paused; it made 20 recommendations.
- The Department introduced working groups and a reporting app; incident/near-miss reporting rose afterward. The Committee still judged upward information flow inadequate.
- Modifications to reduce noise/vibration were still being tested; sufficiency unknown; more fundamental redesign could not be ruled out; further unknown issues could not be excluded.

---

## 2. What is uncertain or not established

- **Root cause(s)** of the noise/vibration problems and whether they are fixable by modification or require redesign.
- **Final technical viability** of Ajax as a capability.
- **Legal/contractual position**: who bears liability, what termination would cost, what rights each party holds.
- **Medical status** of injured personnel (numbers, severity, long-term effects).
- **Counterfactuals**: whether alternatives would have delivered better/faster/cheaper; the actual military cost of each delay.
- **Whether the safety-culture fixes work** over time (rising reports could indicate better reporting, more incidents, or both).
- **Responsibility allocation** between Department, Army, DE&S, advisers, and supplier — the packet describes collective failings but not individual accountability.
- Whether the Department's reluctance to explore alternatives was rational contract management or sunk-cost entrenchment.

---

## 3. People and systems affected

- **Soldiers**: injured personnel; future crews exposed if the vehicle enters service with unresolved defects.
- **The Army**: operating without the intended reconnaissance capability; carrying "operational compromises" whose nature and risk are unspecified.
- **The Department / DE&S / senior responsible owners**: accountable for delivery, safety, and value for money.
- **General Dynamics UK**: contractual counterparty in active dispute; 324 hulls already built.
- **Taxpayers**: £3.2bn spent against an undelivered capability under a firm-priced contract.
- **Future programmes**: the same requirement-writing, escalation, and concurrent-production practices may recur.
- **Parliamentary/public trust** in defence procurement.

---

## 4. Plausible options (descriptive, not recommended)

1. **Continue the contract with modifications**, pending test results, with tighter safety gating.
2. **Pause production/trials** until safety fixes are validated, accepting further delay.
3. **Renegotiate** scope, schedule, requirements (e.g., descope some of the ~1,200 requirements) — noting the 2018 reset reportedly made things worse.
4. **Investigate/prepare alternatives** in parallel (the Committee's recommendation), without committing to exit.
5. **Terminate the contract** and pursue alternatives — consequences depend on legal positions not in the packet.
6. **Governance/safety-process reform** independent of the contract decision: escalation authority, stopping rules, independent safety sign-off, monitoring whether reforms bite.

These are not mutually exclusive; (6) applies under all scenarios, and (4) is compatible with (1)–(3).

---

## 5. Key risks and consequences

- **Continue without resolution**: risk of further injuries; fielding an unsafe or underperforming vehicle; compounding sunk costs.
- **Pause**: delay to a capability the Army has already waited over a decade for; unknown operational risk from the gap; cost of idle production.
- **Renegotiate/reset**: precedent (2018) shows resets can add complexity rather than reduce it.
- **Terminate**: potential write-off of £3.2bn+ and 324 hulls; legal dispute; new procurement timeline; but may stop escalation of commitment to an unfixable design. Packet does not establish the net outcome.
- **Do nothing on alternatives**: if the contract fails later, the Department starts from zero — the Committee explicitly flagged this exposure.
- **Safety reform failure**: rising reports are not yet evidence of resolution; if escalation remains weak, the next warning signal may again reach senior leaders years late.
- **Decision-coupling risk**: the contract decision and the safety decision are linked but distinct — a safe vehicle may still be late and over-complex; a terminated contract does not remedy injured soldiers or capability gaps.

---

## 6. Evidence or checks that could materially change the analysis

- **Modification test results**: sufficient fix vs. fundamental redesign is the single largest pivot point.
- **Contract and legal advice**: termination costs, liability for defects, dispute posture — could flip the economics of continue/exit.
- **Medical findings**: severity and permanence of injuries affect both duty-of-care obligations and litigation/compensation exposure.
- **Independent technical assessment** of whether the design, as specified, is achievable at acceptable safety levels.
- **Root-cause analysis** distinguishing platform-inherent problems from requirements-driven complexity (the ~1,200 requirements).
- **Military assessment** of the actual capability gap and the cost of the Army's "operational compromises."
- **Verification of safety reforms**: audit of whether reports reach decision-makers with authority to stop activity, and whether stopping actually happens.
- **Comparator data**: realistic cost/schedule of alternatives — needed before alternatives are a real option rather than a slogan.
- **Why escalation failed**: the 2014 advisory warning and the ~14-month gap between injury reports (July 2020) and senior-owner awareness (Sept 2020) — whether this was process, culture, or structure determines what fix is needed.

---

## 7. Correctability of mistakes

- **Irreversible or hard to reverse**: injuries already sustained; money already spent; the decade of lost capability time.
- **Partially reversible**: safety processes, governance, escalation paths — reformable at modest cost, and already partially changed.
- **Time-limited reversibility**: the option to pursue alternatives degrades the longer the Department waits without preparing them; conversely, premature termination before modification test results may foreclose a recoverable path. The packet does not establish which way this asymmetry cuts.
- **Path dependence**: 324 hulls built and £3.2bn paid narrow future options regardless of what is decided now.

---

## 8. Facts vs. judgments — kept separate

**Supported**: the contract terms, spend, delivery counts, missed dates, injury acknowledgment, warning timeline (2014 advisory; 2019 trials; July 2020 injuries; Sept 2020 escalation), the King review's existence and 20 recommendations, the Committee's findings and recommendations.

**Uncertain**: root causes, fix feasibility, legal positions, medical outcomes, counterfactual performance of alternatives, individual culpability, whether safety reforms will hold, and anything after June 2022.

**Value judgments a decision-maker must supply** (not derivable from the packet): acceptable safety risk for service personnel; how to weigh sunk costs against future spend; tolerance for capability gap versus risk

### NON-CREDITABLE TAIL — ADVERSE/BURDEN REVIEW ONLY

 of a flawed vehicle; how much confidence in institutional reform is required before resuming exposure of soldiers to trials; and what standard of evidence should trigger pause, redesign, or exit.

---
