# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.

---

# Adjudication packet

Packet ID: `PAIR-BEAAE4DD90`
Case ID: `PAC-4`

## Frozen case packet

CASE: Financial sustainability of the higher education sector in England
CASE_ID: 173bb291d5cdf471946ba050f0915b630d552b1f84cbc7d7cf317bcf7d3d1733

SOURCE BASIS

Primary source: House of Commons Committee of Public Accounts, Eighth Report of Session 2022–23, “Financial sustainability of the higher education sector in England”, published 15 June 2022.
Official report: https://publications.parliament.uk/pa/cm5803/cmselect/cmpubacc/257/report.html

This packet is a bounded factual digest of the Committee’s report. Committee conclusions and recommendations are identified as such and are not treated as a complete account of the sector.

FACTUAL MATERIAL

Higher education providers in England are autonomous institutions with financial and academic independence. To access relevant government funding, or for their students to receive government tuition-fee and maintenance loans, providers must be registered with the Office for Students (OfS). The Department for Education sets higher-education policy and the overall regulatory framework and sponsors the OfS.

In July 2021 there were 254 registered higher-education providers in England, excluding further-education and sixth-form colleges, educating an estimated 2.3 million students. Total provider income in 2019/20 was £36.1 billion, of which 36% came from public sources.

The Committee reported long-term pressures on providers’ finances, including rising costs and inflation, pension pressures, a freeze in the tuition-fee cap, policy uncertainty and changes affecting student finance. The OfS considered the sector more stable than at the start of the pandemic but accepted that risks remained.

The Committee found that the OfS relied heavily, though not exclusively, on financial metrics and did not routinely discuss finances with every individual provider. It did not yet have an integrated model capable of systematically combining changes in costs, income streams and student numbers to identify how pressures might affect individual institutions. The Committee said this risked leaving the regulator without enough information to spot and act on early signs of distress. It also found gaps in the OfS’s view of student experience; for example, the National Student Survey covered final-year undergraduates and did not provide a comparable picture for students earlier in their degrees.

The Committee reported that the number of providers recording an in-year deficit had risen from seven in 2015/16 to 80 in 2019/20. Some providers’ financial viability depended on surpluses from non-publicly funded teaching, particularly overseas-student fees, to subsidise teaching and research whose full economic costs were not recovered from public funding. The Committee and evidence before it noted that reliance on continued growth in overseas recruitment exposed some providers to competition and wider political or international changes.

Student protection plans are a condition of registration and are intended to describe how students would be protected if a provider encountered difficulty. The OfS had previously found these plans highly variable in quality. It had approved some plans below the standard it expected because it considered delaying registration contrary to students’ interests. Weaknesses included optimism about risks, insufficiently specific actions and weak refund or compensation provisions.

The OfS told the Committee that the early pandemic revealed that it lacked tools to intervene quickly if a provider was at risk of failure. A regulatory condition effective from April 2021 allowed it to direct providers considered at material risk. Possible directions included requiring plans to protect students, enabling transfer to another institution, allowing students to complete a course, term or year, preserving evidence of academic credit, and ensuring complaints and compensation arrangements.

The Committee recommended that the OfS improve its understanding of sector and provider pressures and demonstrate this to universities and students. It also criticised the Department’s oversight of the OfS and called for stronger assurance that students would be protected from provider financial distress.

INFORMATION NOT SUPPLIED IN THIS PACKET

This packet does not contain provider-level financial statements, the full distribution of risk across all institutions, individual student testimony, later changes in regulation, or evidence of which providers subsequently failed or recovered. It does not establish that dependence on overseas-student income is itself unsustainable, nor does it quantify the probability or timing of any particular provider failure. It does not reproduce the full evidence submitted to the Committee or the Government’s later response.

REVIEW QUESTION

Using only the information in this packet, what should a person reviewing this situation understand before deciding what action, oversight, or follow-up is warranted?

---

## Response `RESPONSE-D081E1622F`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1238
Blind main-answer words: 1238
Positive-gain-creditable words: 1200

### POSITIVE-GAIN-CREDITABLE TEXT

# Analysis: Financial Sustainability of the English Higher Education Sector (as of mid-2022)

## 1. What the packet establishes (supported facts)

**Structure of the system**
- English HE providers are autonomous institutions; registration with the Office for Students (OfS) is the gateway to public funding and to students receiving tuition-fee/maintenance loans.
- The Department for Education (DfE) sets policy and sponsors the OfS; the OfS is the regulator. Oversight is therefore a two-tier chain: DfE → OfS → providers.
- As of July 2021: 254 registered providers, ~2.3 million students, £36.1bn total income (2019/20), 36% from public sources. A majority of sector income is therefore non-public, which limits but does not eliminate the state's exposure.

**Financial deterioration is documented, not hypothetical**
- Providers reporting in-year deficits rose from 7 (2015/16) to 80 (2019/20) — a large increase in four years.
- Long-term pressures: rising costs and inflation, pension costs, a frozen tuition-fee cap (eroding real-terms income per domestic student), and policy uncertainty around student finance.
- Some providers cross-subsidise teaching and research (whose full economic costs are not recovered from public funding) using surpluses from overseas-student fees. This creates a dependency on continued growth in overseas recruitment, which is exposed to competition and international/political shifts. The packet does **not** establish that this model is unsustainable — only that it is a risk concentration.

**Regulatory gaps identified by the Committee**
- The OfS relied heavily on financial metrics and did not routinely discuss finances with every provider.
- It lacked an integrated model combining costs, income streams, and student numbers to project institution-level effects — risking failure to spot early signs of distress.
- Its view of student experience was incomplete (the National Student Survey covered only final-year undergraduates).
- Student protection plans (a registration condition) were highly variable; some were approved below the OfS's own expected standard because delaying registration was judged contrary to students' interests. Weaknesses included optimism bias, vague actions, and weak refund/compensation provisions.
- The early pandemic showed the OfS lacked tools to intervene quickly. A new condition (effective April 2021) allows it to direct providers at "material risk" — e.g., requiring protection plans, transfer arrangements, course-completion options, credit records, and complaints/compensation mechanisms.

**The Committee's conclusions (attributed, not independently verified here)**
- The OfS should improve, and visibly demonstrate, its understanding of sector and provider pressures.
- The DfE's oversight of the OfS was criticised; stronger assurance on student protection was called for.

## 2. What is uncertain or missing

- **Distribution of risk**: 80 deficit-recording providers says nothing about severity, trajectory, reserves, or proximity to failure. No provider-level data is supplied.
- **Probability and timing of failure**: The packet quantifies neither. It establishes rising stress and weak early-warning capability, not imminent collapse.
- **Post-report developments**: Later regulation, the Government's response, and any subsequent provider failures or recoveries are excluded. Decisions should not assume the situation is frozen at June 2022.
- **Whether overseas-income dependence is a problem in practice**: plausible risk, unquantified.
- **Effectiveness of the April 2021 direction power**: it exists on paper; the packet contains no evidence of its use, adequacy, or speed.
- **Student-level impact**: no testimony or outcome data on students caught in distressed providers.

## 3. Parties and systems affected

- **Students (~2.3m)**: primary bearers of failure risk — disrupted courses, lost credit, weak refund rights.
- **Providers**: heterogeneous; risk concentrated in those structurally deficit-running and dependent on overseas fee growth.
- **OfS**: regulator whose monitoring capability and intervention toolkit are in question.
- **DfE**: accountable for the framework and for overseeing the OfS; exposed politically and financially (e.g., loan-book implications, though the packet does not quantify this).
- **Taxpayers/public funding system**: 36% of sector income; cross-subsidy means public-funded teaching/research quality partly depends on private income streams.
- **Local economies and staff** (implied by provider scale, though not detailed in the packet).

## 4. Plausible options (structural enumeration, not recommendations)

A reviewer or decision-maker could plausibly consider:

1. **Strengthen OfS monitoring**: build the integrated cost/income/student-number model; increase direct financial engagement with providers; widen early-warning indicators beyond metrics.
2. **Raise the standard and enforcement of student protection plans**: refuse or condition registration on adequate plans rather than approving substandard ones; specify refund/compensation minima.
3. **Test and resource the April 2021 intervention power**: run exercises or reviews of whether directions can be issued quickly enough to matter.
4. **Address structural funding gaps**: revisit the fee cap, cost recovery for publicly funded teaching/research, or pension cost treatment — levers held by DfE/Government, not the OfS.
5. **Improve DfE oversight of the OfS**: clearer assurance requirements and reporting.
6. **Targeted follow-up only**: commission data collection (provider-level risk mapping, stress testing) before committing to structural change.
7. **Do nothing further now**: rely on the new condition and the OfS's view that the sector is more stable than at the pandemic's start.

These options are not mutually exclusive; they differ in cost, intrusion into provider autonomy, and speed.

## 5. Key risks and consequences

- **False reassurance risk**: aggregate "sector stability" (OfS view) can mask institution-level failure; the system is only as safe as its weakest providers' students.
- **Late detection risk**: without integrated modelling, intervention may come after options (orderly transfer, teach-out) have narrowed.
- **Moral hazard / standards drift**: approving substandard protection plans to avoid delaying registration trades a visible short-term harm against a less visible contingent one.
- **Concentration risk**: overseas-fee dependence means a geopolitical or market shock could hit multiple providers simultaneously, straining any intervention capacity.
- **Autonomy tension**: providers are independent institutions; heavier monitoring or earlier intervention has real costs and may be contested.
- **Policy-lever mismatch**: some drivers (fee cap, funding rates) sit with Government, so regulatory fixes alone cannot remove underlying pressure.

## 6. Evidence or checks that would materially change the analysis

- Provider-level financial data: distribution of deficits, reserves, liquidity, and dependence ratios on overseas income.
- Stress tests: sensitivity of individual providers to overseas recruitment declines, inflation, or pension cost changes.
- Whether and how the April 2021 direction power has been used, and how quickly.
- Audit of current student protection plan quality against the OfS's own standard, including refund provisions.
- The Government's formal response to the Committee and any post-2022 regulatory changes.
- Evidence on actual student outcomes where providers have faced distress.
- Updated deficit figures beyond 2019/20 — the trend may have worsened, stabilised, or reversed.

## 7. Correctability of mistakes

- **Largely correctable**: monitoring improvements, model-building, plan-quality enforcement, and DfE oversight changes can be adjusted iteratively with modest downside.
- **Poorly correctable**: an unmanaged provider failure is the irreversible scenario — students mid-course may lose time, money, credit, or completed study even with directions in place, and financial harm to students is only partly compensable. This asymmetry (cheap to improve detection early, expensive or impossible to repair a chaotic failure) is the central structural feature a decision-maker should weigh, regardless of what action they ultimately judge proportionate.

## 8. Boundary of this analysis

Everything above derives solely from the packet. The Committee's findings are reported as its findings; no independent verification, provider-level data, or post-June-2022 developments are assumed. No

### NON-CREDITABLE TAIL — ADVERSE/BURDEN REVIEW ONLY

 recommendation is made here: the choice among the options in Section 4 depends on value judgments (acceptable risk to students vs. regulatory burden, role of the state in autonomous institutions) and on evidence this packet does not contain.

---

## Response `RESPONSE-9EA91D19B5`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1330
Blind main-answer words: 1098
Positive-gain-creditable words: 1098

### POSITIVE-GAIN-CREDITABLE TEXT

## Analysis

### What the packet establishes (as of mid-2022, per the Committee's report)

The higher education sector in England comprises autonomous providers that must register with the Office for Students (OfS) to access public funding and student loans. The Department for Education sets policy and oversees the OfS. In 2019/20 the sector took in £36.1 billion, 36% from public sources, across 254 registered providers and roughly 2.3 million students.

The Committee documented a deteriorating financial trend: providers recording in-year deficits rose from seven in 2015/16 to 80 in 2019/20. Long-term pressures named include rising costs and inflation, pension obligations, the frozen tuition-fee cap, and policy uncertainty. A specific structural feature is that some providers depend on surpluses from overseas-student fees to subsidise publicly funded teaching and research whose full economic costs are not recovered. This creates exposure to international competition and political change, though the packet explicitly does not establish that this dependence is unsustainable.

The regulator's picture of the sector had two documented gaps at the time of the report:

1. **Financial visibility.** The OfS relied heavily on financial metrics, did not routinely discuss finances with every provider, and lacked an integrated model combining costs, income, and student numbers. The Committee judged this left the regulator potentially unable to spot early distress.
2. **Student-experience visibility.** The main survey instrument covered only final-year undergraduates, leaving earlier-year students less well observed.

Student protection plans were a registration condition, but the OfS had found them highly variable and had approved some below its own expected standard, on the grounds that delaying registration was contrary to students' interests. Weaknesses included optimism about risk, vague actions, and poor refund/compensation provisions.

The early pandemic showed the OfS lacked tools for rapid intervention. A regulatory condition effective from April 2021 addressed part of this by allowing directions to at-risk providers (student protection plans, transfer, teach-out, credit records, complaints arrangements). Whether this tool has been exercised or proven adequate is not in the packet.

The Committee also criticised the Department's oversight of the OfS and called for stronger assurance that students would be protected from provider financial distress.

### Structural points relevant to any decision

- **The regulator's map of the sector was demonstrably incomplete at the time of the report.** A regulator cannot act on distress it cannot see. The gap is not merely about having more data but about lacking an integrated model — individual metrics were collected, yet the OfS could not systematically combine them into institution-level risk pictures. This is a known, named limitation, not a hypothetical one.
- **The target set of surveillance matters.** Heavy reliance on financial metrics means providers whose distress shows up first in non-financial form (recruitment collapse, sudden overseas-visa changes, governance failure) may be missed. Conversely, the OfS not discussing finances with every provider means its information is concentrated on a subset — the packet does not say which subset or on what basis it was selected.
- **A safety net was weakened deliberately for a stated reason.** Approving below-standard student protection plans to avoid delaying registration is a documented trade-off between one student-interest claim (access now) and another (protection later). Whether that trade-off was well-judged is a value question the packet cannot settle, but a reviewer should know the compromise exists and has known weaknesses.
- **Oversight is layered, and the upper layer was criticised.** The Committee found fault with the Department's assurance over the OfS, meaning weaknesses in the regulator may not themselves be reliably caught by the body sponsoring it.
- **The trend data are historical.** Deficit counts end in 2019/20, and the report was published June 2022. The April 2021 intervention condition post-dates much of the evidence. Current sector state, and whether the Committee's recommendations were acted on, is not covered.

### What is UNKNOWN from this packet

- Provider-level financial condition and the distribution of risk across institutions; whether any provider has since failed or recovered.
- Whether the OfS has since built the integrated model, changed its engagement pattern, or improved protection-plan standards; whether the Department strengthened its assurance.
- Whether the April 2021 direction power has been used and whether it worked.
- Whether overseas-fee dependence is actually unsustainable, and the probability or timing of any specific failure.
- Student testimony, the full evidence base, and the Government's response to the report.
- Whether the OfS's unobserved provider subset overlaps with the highest-risk providers — the packet gives no basis to say either way.

These gaps matter because some of them are load-bearing: for example, deciding whether *new* oversight is needed depends partly on whether the April 2021 powers and any post-2022 changes have already closed the identified gaps. That cannot be resolved here.

### Decision-relevant framing (kept separate from the facts)

Nothing in this packet by itself establishes that any particular intervention is warranted now; the evidence is a snapshot ending around mid-2022 with explicitly acknowledged unknowns about what followed. What it does support is the following understanding for a reviewer:

1. There was a documented, worsening financial trend and a documented dependence on a volatile income stream in part of the sector, with no finding that this dependence is sustainable or unsustainable.
2. The regulator had admitted and Committee-identified blind spots in both financial and student-experience information, and a previously demonstrated lack of fast intervention tools, only partly remedied by April 2021.
3. The student protection mechanism in place was of known variable quality, with some sub-standard approvals made as a deliberate trade-off.
4. The assurance chain above the regulator was itself criticised.

A reasonable first-order question for anyone deciding on action is therefore not "what should be done?" but "what has changed since this report?" — specifically, the status of the integrated model, protection-plan standards, use of the 2021 direction power, and the Department's assurance arrangements. If those are unchanged, the Committee's concerns stand as documented, unresolved findings. If they have changed, this packet's findings may be historical rather than current. That determination requires information outside this packet and should be flagged as such rather than assumed in either direction.

Any value judgment — for instance, how much weight to put on current access versus future protection, or how much sector risk is tolerable — is not settled by the material here and would need to come from an explicit source (policy, law, or the reviewer's own mandate), not from the report's structure alone.

---

---
