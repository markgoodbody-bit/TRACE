# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.

---

# Adjudication packet

Packet ID: `PAIR-CBAFDF1FFD`
Case ID: `PAC-5`

## Frozen case packet

CASE: Child Maintenance
CASE_ID: 6bf2c8e67538aa04ac6aa985971f67a0e613d4655fd6c6eebab9caef29e4892c

SOURCE BASIS

Primary source: House of Commons Committee of Public Accounts, Ninth Report of Session 2022–23, “Child Maintenance”, published 22 June 2022.
Official report: https://publications.parliament.uk/pa/cm5803/cmselect/cmpubacc/255/report.html

This packet is a bounded factual digest of the Committee’s report. Committee conclusions and recommendations are identified as such and are not treated as a complete account of every family, payment, policy constraint or later development.

FACTUAL MATERIAL

The Committee reported an estimated 3.6 million children in 2.4 million separated families in Great Britain. Child maintenance covers how a child’s living costs are paid when one parent does not live with the child. The Department for Work & Pensions is responsible for policy and operates the statutory Child Maintenance Service (CMS), introduced in 2012 after earlier Child Support Agency schemes.

At the time of the report, 18% of separated families had a statutory CMS arrangement, 38% had a family-based arrangement and 44% had no arrangement. The Committee estimated that around 1.8 million children of separated families did not benefit from child maintenance. It concluded that the intended integrated, cross-government support system for separated families had not materialised and criticised the Department for not leading that integration.

The statutory scheme has two main payment routes. Under Direct Pay, the Department calculates maintenance but payments are made directly between parents. Under Collect and Pay, the Department collects from the paying parent and transfers the payment to the receiving parent, charging fees. Non-resident parents paid an estimated £1 billion through statutory arrangements in 2020–21; administration cost the taxpayer £322 million.

The Department did not routinely monitor whether Direct Pay payments were actually made. Around half of new Direct Pay arrangements were reported as not sustained or not effective, allowing unpaid maintenance to build before some cases moved to Collect and Pay. The Committee said enforcement was too slow and that arrears could continue growing while cases moved through legally defined enforcement stages. It reported that unpaid maintenance on Collect and Pay had reached £440 million by October 2021 and cited a forecast that, without further action or write-off, outstanding arrears could reach £1 billion by March 2031.

Affordability also affected enforcement and payment. The Committee reported that low-income paying parents were disproportionately represented among those with arrears and that some combined effects of child-maintenance payments, benefits withdrawal and council-tax reductions could create very high effective marginal rates as income increased. It also noted that some statutory earnings thresholds used in maintenance calculations had not been updated since 1998.

The Committee found that CMS take-up was lower than expected and that the Department did not know whether all groups found the service equally accessible or achieved similar outcomes. Departmental research indicated that low-income families, disabled people and families with higher parental conflict were more likely to have no maintenance arrangement. The report also recorded lower CMS use among some minority ethnic groups and said the Department had not researched the reasons.

The report described specific risks for victims and survivors of domestic abuse. Evidence before the Committee warned that child-maintenance arrangements can be used by an abusive former partner to continue abuse and that Direct Pay may increase risk by requiring contact over payments.

The Committee also criticised customer-service performance and the handling of complaints. It said the Department needed better measures to distinguish unavoidable dissatisfaction from systemic service problems.

Recommendations included stronger cross-government integration; better understanding of access and outcomes for different groups; faster and better-informed enforcement; a strategy for growing arrears that considered affordability and potentially uncollectable debt; review of payment affordability and calculation thresholds; stronger fraud-and-error assessment; and use of the digital-transformation programme to improve service evidence and performance.

INFORMATION NOT SUPPLIED IN THIS PACKET

This packet contains no individual family case files, payment histories, court records or testimony beyond the aggregate findings reflected in the Committee report. It does not establish why any specific parent paid or did not pay, which arrears were realistically recoverable, the prevalence or severity of abuse in Direct Pay cases, the eventual effects of the planned digital transformation, or how legislation and policy changed after June 2022. It does not provide the Government’s later response or a complete account of perspectives from receiving parents, paying parents, children, staff and support organisations.

REVIEW QUESTION

Using only the information in this packet, what should a person reviewing this situation understand before deciding what action, oversight, or follow-up is warranted?

---

## Response `RESPONSE-EBF892AFBC`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1243
Blind main-answer words: 1243
Positive-gain-creditable words: 1200

### POSITIVE-GAIN-CREDITABLE TEXT

# Analysis: Child Maintenance Service (based solely on the packet)

## 1. What the packet supports (established facts)

- **Scale of the system:** ~3.6 million children in 2.4 million separated families in Great Britain; the Department for Work & Pensions (DWP) is responsible for policy and operates the statutory Child Maintenance Service (CMS), created in 2012.
- **Coverage gaps:** Only 18% of separated families had a statutory arrangement; 38% had family-based arrangements; 44% had none. ~1.8 million children did not benefit from maintenance.
- **Cost and value flows:** Non-resident parents paid ~£1 billion through statutory arrangements in 2020–21; administration cost taxpayers £322 million — roughly £1 of administration per £3 transferred.
- **Direct Pay weakness:** DWP did not routinely monitor whether Direct Pay payments were actually made; about half of new Direct Pay arrangements were not sustained or not effective, letting arrears accumulate before escalation to Collect and Pay.
- **Arrears and enforcement:** Unpaid maintenance on Collect and Pay reached £440 million by October 2021; a cited forecast projected arrears could approach £1 billion by March 2031 absent action or write-off. Enforcement was found too slow, with arrears growing during legally defined stages.
- **Affordability problems:** Low-income paying parents were disproportionately represented among arrears cases; interactions with benefits withdrawal and council-tax reductions could produce very high effective marginal tax rates; some earnings thresholds had not been updated since 1998.
- **Equity and access gaps:** CMS take-up was below expectations; DWP did not know whether all groups had equal access or outcomes. Research indicated low-income families, disabled people, and high-conflict families were more likely to have no arrangement; some minority ethnic groups used CMS less, with reasons unresearched.
- **Domestic abuse risk:** Evidence warned that maintenance arrangements can be used by an abusive ex-partner to continue abuse, and that Direct Pay may heighten risk because it requires ongoing payment contact.
- **Cross-government failure:** The intended integrated support system for separated families had not materialised; the Committee criticised DWP for not leading integration.
- **Service quality:** Customer service and complaint handling were criticised; DWP lacked measures to separate unavoidable dissatisfaction from systemic failure.

**Important attribution note:** These are a parliamentary committee's findings as of June 2022. They carry institutional weight but are one source's assessment, not adjudicated facts, and reflect a single point in time.

## 2. What remains uncertain (explicitly not established)

- Why any specific parent did or did not pay; the mix of inability, unwillingness, avoidance, and administrative failure behind arrears.
- Which arrears are realistically recoverable versus effectively dead debt.
- Prevalence and severity of abuse within Direct Pay cases specifically.
- Whether the planned digital transformation delivered improvements.
- Legislative or policy changes after June 2022, and the Government's formal response to the report.
- Full perspectives of receiving parents, paying parents, children, CMS staff, and support organisations.
- The composition of the 44% with no arrangement (satisfied informal payers vs. genuinely unsupported families) is not fully resolved — the 38% family-based figure overlaps conceptually but the packet does not detail what "no arrangement" households actually do.

## 3. People and systems affected

- **Children** (up to ~1.8 million not benefiting) — the primary intended beneficiaries; financial shortfalls may affect their living standards.
- **Receiving parents** — bear the consequences of non-payment, slow enforcement, and (in Direct Pay) potentially unsafe contact.
- **Paying parents** — face possible unaffordable assessments, outdated thresholds, and high effective marginal rates that may drive arrears rather than resolve them.
- **Victims/survivors of domestic abuse** — exposed to a distinct safety risk channel through payment contact.
- **Taxpayers** — funding £322m/year administration plus accumulating arrears exposure.
- **CMS/DWP staff** — operating within slow, legally staged enforcement and weak evidence systems.
- **Other government bodies** — the integration failure implicates departments beyond DWP (benefits, council tax, family support).

## 4. Plausible directions a reviewer could examine (structural, not endorsed)

The Committee's recommendations map to these action areas; whether to pursue each is a separate judgment:

1. **Monitoring Direct Pay** — verify payments rather than assume them; triggers for earlier escalation.
2. **Faster enforcement** — compress or streamline legally defined stages; earlier intervention before arrears compound.
3. **Arrears strategy** — segment debt into recoverable vs. uncollectable; consider write-off policy alongside collection effort.
4. **Affordability review** — update 1998-era thresholds; examine combined marginal-rate effects.
5. **Access and equity research** — investigate group-level differences (low income, disability, ethnicity, conflict level).
6. **Domestic abuse safeguards** — reduce reliance on direct payment contact where abuse risk exists.
7. **Cross-government integration** — assign and enforce leadership for the wider separated-families support system.
8. **Better performance measurement** — distinguish systemic failure from inherent dissatisfaction; use digital transformation to build evidence.

## 5. Key risks and consequences

- **Inaction risk:** arrears trajectory toward £1 billion by 2031; continued non-benefit for ~1.8 million children; unchecked safety exposure for abuse survivors.
- **Enforcement-side risk:** aggressive collection from low-income payers with unaffordable assessments may be futile, costly, and harmful — the packet itself links low income to arrears.
- **Write-off-side risk:** writing off debt without distinguishing recoverable from unrecoverable arrears could forgo legitimate support for children and weaken payment incentives.
- **Direct Pay reform risk:** shifting cases to Collect and Pay adds fees and state involvement; leaving them in Direct Pay risks non-payment and abuse-facilitating contact. The packet does not resolve the optimal balance.
- **Measurement risk:** without knowing group-level access and outcomes, reforms could widen rather than narrow disparities.
- **Fiscal risk:** the 32% admin-cost-to-transfer ratio implies any expansion of Collect and Pay has significant cost implications.

## 6. Evidence or checks that could materially change the analysis

- The Government's post-June-2022 response and any implemented reforms (could render parts of this analysis historical).
- Updated arrears figures and Direct Pay effectiveness data (confirm or refute the £1bn trajectory).
- Segmentation of arrears by cause and recoverability (would decisively shape the arrears strategy choice).
- Data on abuse prevalence in Direct Pay (would calibrate how far safety concerns should drive design).
- Post-transformation service metrics (would show whether digital change addressed evidence gaps).
- Group-level access/outcome research (would determine whether equity interventions are needed and where).
- Perspectives of frontline staff, receiving and paying parents, and support organisations (would test whether Committee findings reflect lived operation).

## 7. Reversibility and timing

- **Some mistakes are correctable:** thresholds can be updated, monitoring added, processes redesigned.
- **Some are not fully correctable:** arrears that accumulate during slow enforcement may become permanently uncollectable; children who go without support during childhood cannot be retroactively compensated for lost living standards; harm from abuse-facilitating contact may be irreversible.
- **Timing asymmetry:** delay itself creates consequences (compounding arrears, aging-out children), so "wait for more evidence" is not a neutral option — though acting on stale (pre-June-2022) data carries its own risk. A reviewer should establish the current state before treating the report as describing the present.

## 8. Bottom line for a reviewer (descriptive, not prescriptive)

The packet supports a well-evidenced picture of systemic underperformance as of mid-2022: low coverage, unmonitored payments, slow enforcement, growing arrears, affordability distortions, equity blind spots, and a specific safety risk channel. The packet does not establish current conditions, the causes of individual non-payment, or which reforms the Government has since adopted. Any consequential decision made solely on this packet

### NON-CREDITABLE TAIL — ADVERSE/BURDEN REVIEW ONLY

 should first verify what has changed since June 2022 and obtain the missing perspectives and recoverability data, because several of the most consequential choices (arrears write-off vs. collection, Direct Pay design, enforcement speed) hinge on facts this packet explicitly does not contain.

---

## Response `RESPONSE-E2E681FB1A`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1205
Blind main-answer words: 962
Positive-gain-creditable words: 962

### POSITIVE-GAIN-CREDITABLE TEXT

## What a reviewer should understand before deciding on action

### What the evidence actually is

Everything in this packet traces to one source: a June 2022 House of Commons Public Accounts Committee report. The Committee's findings are *reported* conclusions based on evidence it heard; they are not independently verified here, and the packet contains no underlying case files, payment records, or testimony. Nothing after June 2022 — the Government's response, the digital transformation programme's effects, any legislative change — is known from this material. Any decision made now would need to check whether the described state still holds, because several load-bearing numbers (arrears levels, caseload mix, service performance) will have moved.

### The picture the numbers do and do not support

- Scale is well supported: ~3.6 million children in 2.4 million separated families; only 18% of separated families used the statutory service; 44% had no arrangement at all; an estimated 1.8 million children received no maintenance benefit.
- £1 billion was paid through statutory arrangements in 2020–21 against £322 million in administration costs — a ratio relevant to any value judgment about the system's cost-effectiveness, though the packet supplies no comparison basis for judging whether 32p of admin per £1 transferred is high or low for this kind of intervention.
- Recorded arrears (£440 million by October 2021) cover only Collect and Pay, the route the Department can see. Direct Pay — the other statutory route — was not routinely monitored, so total unpaid maintenance is unknown and certainly larger than recorded arrears. The often-quoted "around half of new Direct Pay arrangements not sustained or not effective" figure itself rests on limited observation, since routine monitoring did not exist. Its basis should be treated as uncertain, and the true failure rate could be higher or lower.

This is the single most important structural fact for a decision-maker: **the route with the least state involvement is also the route with the least state visibility.** Choosing between Direct Pay and Collect and Pay is simultaneously a choice about payment security, fees, parental contact, and what the Department can even observe.

### Where uncertainty is load-bearing

1. **Why maintenance goes unpaid is not established.** Low-income paying parents are over-represented among arrears cases, and some face very high effective marginal rates from the interaction of maintenance, benefits withdrawal and council-tax reduction. That pattern is consistent with inability to pay, but also with other causes. The packet does not distinguish inability, unwillingness, dispute, or evasion — and the right intervention differs sharply by cause: faster enforcement addresses unwillingness; affordability reform addresses inability; write-off strategy addresses uncollectable debt. Treating all arrears as one kind of problem would bake a causal assumption into policy without evidence.

2. **The £1 billion-by-2031 arrears figure is a conditional forecast**, dependent on no further action and no write-off. It is a projection, not a measurement, and should not be quoted as an established outcome.

3. **Access and outcome gaps are correlational.** Research indicated lower arrangement rates among low-income families, disabled people, higher-conflict families, and some minority ethnic groups; the Department had not researched causes. Whether the service is inaccessible, unattractive, or simply not reaching these groups is unknown — and each explanation implies different follow-up.

4. **Domestic abuse risk is a credible mechanism with unknown prevalence.** Evidence to the Committee warned that maintenance arrangements can be used to continue abuse and that Direct Pay's payment contact may increase risk. The packet does not quantify how often or how severely. What is established structurally is a conflict: the route that reduces fees and state involvement is the route that requires ongoing contact between ex-partners. A policy shift toward Direct Pay for cost reasons carries a risk the packet cannot size.

5. **Stale parameters.** Some earnings thresholds in maintenance calculations date from 1998. Whatever was correct in 1998 cannot be assumed correct in 2022 without checking; affordability conclusions rest partly on inputs a quarter-century out of date.

### Timing structure

Arrears grow while cases move through legally defined enforcement stages — delay is not neutral; each month of slow enforcement converts into larger accumulated debt and longer child hardship. However, "growing" does not mean "irrecoverable": the packet does not establish which arrears are realistically collectible. Some may harden into effectively uncollectable debt (low-income payers, old balances), which is precisely why the Committee recommended an arrears strategy distinguishing enforceable from unrecoverable amounts. A reviewer should not treat the stock of arrears as either fully recoverable or fully lost; both claims are unsupported.

### What a decision would rest on beyond these facts

The packet supports structural observations, not value choices. Deciding between options requires weighting things the facts do not rank: children's income security against low-income paying parents' capacity to pay; taxpayer administration cost against collection completeness; reduced state involvement against abuse exposure and observability; speed of enforcement against accuracy and fairness of assessments. The Committee's recommendations (integration, access research, faster enforcement, arrears strategy, affordability review, fraud assessment, digital-enabled evidence) are its judgments about those weights — reported as such, not derived by the packet.

### Practical implication of the evidence gaps

Before choosing actions, a reviewer would want, at minimum: current post-2022 data; actual Direct Pay payment rates from a monitoring source; breakdown of arrears by cause and collectability; and evidence on abuse prevalence by payment route. Deciding enforcement speed, write-off policy, or route design *without* those is deciding under known blind spots — which may still be necessary, but should be recorded as a choice made with incomplete observation, not as a conclusion the evidence forced. Doing nothing is also a selection: under the status quo default, arrears continue accumulating and ~44% of separated families remain outside any arrangement.

---

---
