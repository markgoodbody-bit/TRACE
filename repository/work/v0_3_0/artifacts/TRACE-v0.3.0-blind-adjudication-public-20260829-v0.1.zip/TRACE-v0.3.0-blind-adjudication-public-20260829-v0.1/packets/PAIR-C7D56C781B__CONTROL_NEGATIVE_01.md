# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.

---

# Adjudication packet

Packet ID: `PAIR-C7D56C781B`
Case ID: `CONTROL_NEGATIVE_01`

## Frozen case packet

CASE: Automatic entrance door at a public library
CONTROL TYPE: low-complexity synthetic case

FACTUAL MATERIAL

A public library has one main automatic entrance door and a separate manual side door. On Monday morning, staff noticed that the automatic door sometimes failed to reopen promptly when a person or object remained in the threshold. No injury has been reported.

The library closed the automatic door and directed visitors to the manual side door. The side door is accessible, is on the same frontage, and has been checked by staff. A staff member is available to assist anyone who asks for help.

A qualified service technician attended that afternoon. The technician found dirt on the presence-sensor lens and no visible damage to the sensor, motor, door track or control unit. The lens was cleaned. The technician then performed 20 consecutive obstruction tests using the manufacturer’s normal test procedure. The door reopened correctly in all 20 tests.

The technician says the door may be returned to service. The technician recommends that staff visually check the sensor lens at opening time each day for the next week and call for service if the problem recurs. A replacement sensor is available within two working days if recurrence suggests an intermittent component fault.

The library manager can keep the automatic door closed and continue using the manual side door, or reopen the automatic door with the recommended daily checks. Either choice can be changed later. There is no scheduled event that requires use of the automatic door today.

INFORMATION NOT SUPPLIED IN THIS PACKET

There is no evidence of an injury, hidden structural damage, previous recurrence, a manufacturer recall, or another entrance problem. No additional technical test results are available. The packet does not establish that a future fault is impossible.

REVIEW QUESTION

Using only the information in this packet, what should a person reviewing this situation understand before deciding what action, oversight, or follow-up is warranted?

---

## Response `RESPONSE-C8AC4C669A`

Original visible-answer limit status: `WITHIN_OUTPUT_LIMIT`
Original full visible-answer words (including removed provenance note, if any): 1173
Blind main-answer words: 1173
Positive-gain-creditable words: 1173

### POSITIVE-GAIN-CREDITABLE TEXT

# Analysis: Automatic Entrance Door at Public Library

## 1. Facts Supported by the Packet

**The fault and its resolution:**
- The automatic door intermittently failed to reopen promptly when a person or object remained in the threshold (observed Monday morning).
- No injury occurred.
- A qualified technician attended the same day, found dirt on the presence-sensor lens, and found no visible damage to the sensor, motor, track, or control unit.
- After cleaning, the door passed 20 consecutive obstruction tests using the manufacturer's normal test procedure.
- The technician judged the door fit to return to service.

**Current mitigation:**
- The automatic door is closed; visitors use a manual side door that is accessible, on the same frontage, staff-checked, and supported by an available staff member.

**Proposed follow-up (technician's recommendation):**
- Daily visual check of the sensor lens at opening for one week.
- Call for service if the problem recurs.
- A replacement sensor is available within two working days if an intermittent component fault is suspected.

**Decision structure:**
- The manager has two options: keep the automatic door closed, or reopen it with daily checks.
- Either choice can be changed later.
- No event today requires the automatic door.

## 2. What Is Uncertain (Not Established by the Packet)

- **Root cause certainty:** Dirt on the lens is a plausible explanation consistent with the findings, but the packet does not prove dirt caused the fault. The fault was intermittent; 20 passes after cleaning are consistent with a fixed problem but do not rule out an intermittent component fault that simply did not manifest during testing.
- **Hidden damage:** Only "no visible damage" was found. No deeper diagnostic results are supplied.
- **History and context:** No information on prior occurrences, the door's age, maintenance history, manufacturer recalls, or whether the sensor model has known issues.
- **Severity potential:** The packet does not describe what "failed to reopen promptly" means in the worst case — e.g., whether the door could close on a person, or merely hesitated. The failure mode's potential harm is uncharacterized.
- **Test representativeness:** 20 consecutive tests on one afternoon may not reproduce the conditions (e.g., weather, dust, foot traffic, time of day) under which the fault appeared.
- **Manual-door adequacy under load:** The side door is described as accessible and checked, but there is no information on capacity during peak periods, queuing, or suitability for all users (e.g., people with limited upper-body strength who may not ask for help).

## 3. People and Systems Affected

- **Library visitors**, especially those with mobility impairments, stroller or wheelchair users, children, and elderly visitors — both as potential beneficiaries of the automatic door and as the parties exposed if the sensor fails again while the door is in service.
- **Staff**, who bear the burden of daily checks, assisting at the manual door, and responding to any recurrence.
- **The library as an institution** — service quality, accessibility obligations, and liability exposure if a known intermittent fault recurs and causes harm.
- **The technician/service provider** — their judgment is the basis for any return-to-service decision.

## 4. Plausible Options

1. **Reopen the automatic door now**, with the recommended daily lens checks and a clear trigger (any recurrence) for closing it again and calling service.
2. **Keep the automatic door closed temporarily** (e.g., for the one-week observation period or some part of it) and monitor, reopening after a period without recurrence — noting the door cannot be "tested for recurrence" while closed, so this option mainly buys time for further diagnostics rather than evidence of fixed operation.
3. **Keep it closed pending additional diagnostics** — e.g., proactive sensor replacement (available in two working days) or further testing — though the packet identifies no positive finding that currently justifies replacement.
4. **Hybrid:** Reopen with enhanced precautions beyond the technician's minimum — e.g., more frequent checks than daily, a staff spot-check of obstruction function each morning, signage, or a staff member near the entrance during busy periods.

All options remain reversible.

## 5. Key Risks and Consequences

**If reopened:**
- Risk of recurrence with a person in the threshold. Consequences depend on the uncharacterized failure mode; worst case involves contact between door and person.
- Recurrence after a known prior fault carries greater institutional/liability significance than the initial fault, because the library was on notice.
- Mitigants: same-day closure capability, daily checks, defined service trigger, rapid parts availability.

**If kept closed:**
- Reduced convenience and potentially reduced accessibility for users who cannot easily use a manual door and do not ask for assistance.
- Sustained staff burden at the side door.
- Low direct safety risk; main costs are service quality and equity of access.

**Common to both:**
- No option eliminates the possibility of a future fault; the packet explicitly does not establish that.

## 6. Evidence or Checks That Could Materially Change the Analysis

- Any **injury or near-miss** report connected to the door.
- **Recurrence** of the fault after reopening (or during any extended testing) — would shift the picture toward an intermittent component fault and strengthen the case for sensor replacement.
- **Prior history**: earlier complaints, maintenance logs, or a manufacturer recall/bulletin for this sensor or door model.
- **Clarification of the failure mode**: whether the door can close on an obstruction versus merely failing to reopen — this substantially changes the severity assessment.
- **Longer or condition-varied testing** (e.g., across different days, weather, or lighting) to increase confidence the fault is resolved.
- **Deeper diagnostics** beyond visual inspection (e.g., sensor output testing, control-unit error logs).
- **Accessibility audit of the manual-door arrangement**, including peak-load performance and usability without staff assistance.

## 7. Correctability of Mistakes

This is a highly reversible decision, which materially lowers the stakes of either choice:
- Reopening can be reversed immediately if the fault recurs, and a replacement sensor is available within two working days.
- Keeping the door closed can be reversed at any time with no technical barrier.
- The main *irreversible* risk is harm occurring in the window between a recurrence and detection/closure — which is why the daily check and a clearly understood response trigger matter if the door is reopened. A morning check alone would not detect a fault developing mid-day; staff and visitor reporting during operating hours is the only detection mechanism for that window.

## 8. What a Reviewer Should Understand Before Deciding

- The evidence supports a return to service as a *reasonable* option: a plausible cause was found and corrected, the manufacturer's test procedure passed, and a qualified technician cleared the door.
- The evidence does not *exclude* an intermittent fault; the technician's own recommendation (daily checks, service trigger, available replacement part) implicitly acknowledges residual uncertainty.
- The fallback arrangement (accessible manual door with staff assistance) is functioning, so there is no operational pressure to reopen today.
- The decision is reversible in both directions; the residual risk is concentrated in the detection gap between daily checks if the door is reopened.
- The decision turns on unquantified severity of the failure mode and on how much residual uncertainty the reviewer accepts given a working alternative entrance — neither of which the packet resolves.

---

## Response `RESPONSE-75E7C90EDD`

Original visible-answer limit status: `WITHIN_OUTPUT_LIMIT`
Original full visible-answer words (including removed provenance note, if any): 902
Blind main-answer words: 829
Positive-gain-creditable words: 829

### POSITIVE-GAIN-CREDITABLE TEXT

A reviewer should separate what is established from what remains open.

**Established in the packet:** The automatic door had a reported problem on Monday morning: it sometimes did not reopen promptly when a person or object remained in the threshold. No injury is reported. The library removed the door from service and routed people to a manual side door that is described as accessible, on the same frontage, checked by staff, with staff help available if asked. A qualified technician attended the same afternoon, found dirt on the presence-sensor lens, saw no visible damage to the sensor, motor, track, or control unit, cleaned the lens, and ran 20 consecutive obstruction tests using the manufacturer’s normal procedure. All 20 reopened correctly. The technician’s view is that the door may be returned to service, with daily opening-time visual lens checks for a week and a service call if the problem recurs. A replacement sensor is available within two working days if recurrence points to an intermittent component fault. Both choices—keep the automatic door closed or reopen it with checks—are described as changeable later. No event today requires the automatic door.

**Not established:** The packet does not prove dirt was the sole cause, only that dirt was present, was corrected, and was followed by successful tests. Because the original fault was intermittent, 20 passes under one normal test procedure are reassuring but do not exclude an intermittent sensor, wiring, control, track, power, or environmental problem. The packet supplies no injury, hidden damage, prior recurrence, recall, additional entrance defect, or extra test data; those are unknowns outside this packet, not affirmative facts that the door is safe forever or unsafe. The technician’s “may be returned to service” is a professional report after inspection and testing, not a guarantee. It is also unknown whether the manual side door preserves equivalent convenience and independent access for every user at all times, even though it is accessible and checked and assistance is available.

**Decision-relevant structure:** The immediate safety question is narrow: whether the door now reverses/reopens promptly when something is in the threshold. The evidence supports that it did so after cleaning across 20 consecutive trials, under the stated procedure. The residual risk is mainly about recurrence between checks and whether the daily visual check is the right control for the failure mode. A visual lens check can catch dirt, blockage, obvious misalignment, or contamination, but it is not established to detect every electrical or mechanical intermittency. So the control helps; it is not a complete verification regime.

There is no urgency forcing reopening today, because no scheduled event needs the automatic door and a checked accessible manual route exists. That lowers the cost of caution. At the same time, keeping the automatic door closed shifts burden to the manual door, staff assistance, signage, queueing, and users who may benefit from powered opening; it also removes a redundant entrance. Reopening restores normal access but depends on follow-through: someone must actually perform the opening-time lens check, record it, know the stop rules, and take the door out of service promptly if anything abnormal appears. Either path is reversible as a policy, but a realised future incident would not be undone merely because the policy can later change.

A practical reviewer would want clear triggers before choosing oversight: reopen only if the daily checks are assigned to a named role, logged briefly, and done before public opening; any failure, sluggish reopen, repeated obstruction anomaly, visitor report, impact, cleaning-chemical exposure, unexplained sensor fault, or inability to perform the visual check should close the automatic door again and route to the manual door. If the problem recurs, the packet supports treating it as a possible intermittent component fault rather than “dirt again” by default: keep the door out of service, call the technician, and use the two-working-day replacement-sensor route if indicated. After any recurrence and repair, return-to-service should be based on fresh inspection/testing, not on Monday’s 20 passes.

The manual side door should remain genuinely usable while it is the fallback: unobstructed, signed, staffed as promised, and checked at relevant times, especially opening and peak periods. If the library reopens the automatic door, the manual door remains a backup rather than the primary route.

**Bottom line for understanding, not a verdict:** The packet supports a supervised, reversible return to service with explicit daily checks and stop rules as a reasonable option to consider; it also supports keeping the automatic door closed today without needing an event-driven reason, because the fallback is available and the fault was intermittent. The choice turns on the library’s confidence that the check/log/response routine will be executed and on how much residual intermittent-fault risk it is willing to carry while normal access is restored. The evidence does not justify treating the door as proven permanently fixed, nor treating it as known dangerous.

---
