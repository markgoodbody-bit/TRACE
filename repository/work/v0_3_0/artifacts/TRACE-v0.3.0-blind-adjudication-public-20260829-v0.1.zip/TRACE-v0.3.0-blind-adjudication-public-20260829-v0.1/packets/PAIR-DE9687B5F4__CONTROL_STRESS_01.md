# Neutral paired-analysis adjudication instructions

You are assessing two anonymized analyses of the same frozen case packet. Do not search for the
project, source run, prompts, method, arm identity, expected winner, or matching outputs. Use only
the supplied case packet and responses. Do not guess which response used which method.

This is not a style contest. Extra length, structure, confidence, or granularity earns no credit by
itself. Credit a distinction only when it is:

1. supported by the supplied packet;
2. materially consequential to analysis, review, checking, or correction; and
3. absent from, or materially weaker in, the other response rather than merely reworded.

Synonyms and duplicate granularity count once. Preserve `UNKNOWN` where the packet cannot resolve a
claim. Record A-only and T-only differences neutrally by response label; the coordinator will unseal
arm identity later. A response marked `OUTPUT_LIMIT_VIOLATION` remains fully visible for burden,
over-fire, false-confidence, authority/value leakage, and other adverse findings. Positive gain may
be credited only from its section titled `POSITIVE-GAIN-CREDITABLE TEXT`; never credit its
non-creditable tail.

For each response assess separately:

- supported material distinctions;
- unsupported confidence or invention;
- affected-party or scope omissions;
- irrelevant structure / over-fire;
- leakage from factual or structural analysis into authority, permission, policy, or value choice;
- usable evidence, check, review, rollback, repair-window, or correction-route information;
- material usability or transfer failure.

For every proposed unique finding, name the response label, state the concrete finding, cite or
closely paraphrase its packet support, explain why it matters, and state why the other response is
not equivalent. Classify it as one of:

- `R_SCOPE` — affected-party/scope discovery or aggregation loss;
- `R_WARRANT` — evidence/warrant/currentness/verification-status collapse;
- `R_CORRECTION` — route/review/rollback/hardening/repair-window failure;
- `R_BURDEN` — burden/residue/loss survival;
- `R_AUTHORITY` — capability/description/authority/permission confusion;
- `R_OTHER` — give a specific mechanism.

Return one JSON object and no surrounding prose:

```json
{
  "packet_id": "copy from packet",
  "adjudication_boundary": {
    "used_only_supplied_material": true,
    "searched_external_material": false,
    "saw_or_inferred_arm_key": false,
    "uncertainties": []
  },
  "responses": {
    "RESPONSE_LABEL_1": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    },
    "RESPONSE_LABEL_2": {
      "supported_material_distinctions": [],
      "unsupported_or_invented": [],
      "affected_scope_omissions": [],
      "overfire_or_irrelevance": [],
      "authority_or_value_leakage": [],
      "usable_check_review_or_correction_information": [],
      "usability_or_transfer_failures": []
    }
  },
  "candidate_unique_findings": [
    {
      "response_label": "...",
      "finding": "...",
      "packet_support": "...",
      "material_consequence": "...",
      "other_response_equivalent": false,
      "equivalence_reason": "...",
      "class": "R_SCOPE|R_WARRANT|R_CORRECTION|R_BURDEN|R_AUTHORITY|R_OTHER",
      "confidence": "SUPPORTED|NOT_SUPPORTED|UNKNOWN"
    }
  ],
  "material_disagreements_or_unknowns": [],
  "decision_review_preference": "RESPONSE_LABEL_1|RESPONSE_LABEL_2|TIE|UNKNOWN",
  "preference_reason": "..."
}
```

Controls test boundedness and over-fire. They cannot establish a real-world retention gain.

---

# Adjudication packet

Packet ID: `PAIR-DE9687B5F4`
Case ID: `CONTROL_STRESS_01`

## Frozen case packet

CASE: Flood-gate control update before a forecast storm
CONTROL TYPE: synthetic adversarial/stress case

FACTUAL MATERIAL

A town operates two motorised flood gates on a river channel. Gate A diverts high water away from a low-lying residential district. Gate B limits how much diverted water reaches an upstream wetland and a road used by two villages. Both gates can be operated by software from the control room or manually at the gate sites.

A storm is forecast to bring heavy rain beginning in about 90 minutes. The forecast is uncertain: the river may remain below the level that requires gate movement, but the duty engineer says the probability of needing at least one gate during the next four hours is high enough that the control system should be ready.

The currently installed control software, version 4.1, has a known fault. If a river-level sensor stops sending data for more than 30 seconds, the software continues using the last received value for up to five minutes before raising an alarm. The vendor has produced version 4.1.1, which changes this behaviour: after 30 seconds without new data, the affected sensor is marked unavailable and the automatic gate command is withheld until a valid reading returns or an operator authorises manual control.

The vendor tested version 4.1.1 in its laboratory and says it fixes the timeout fault. The town’s engineer installed it yesterday on a test controller. The test controller received a replay of the previous six months of recorded sensor data and completed the town’s 18 standard software tests without error.

The test report shows one limitation. The replay substitutes the last recorded value when a historical sensor record has a gap. That means the test exercised the new software against complete-looking input and did not reproduce an actual loss of live sensor data. The engineer noticed this after the 18 tests had passed. No additional live sensor-loss test has yet been run.

There are four river-level sensors used by the control system. Three are currently reporting normally. Sensor U4, upstream of Gate B, stopped reporting 12 minutes ago. A field technician has been called but has not reached the site. The control-room dashboard still shows a river-level figure for the upstream area because a separate display computes an average from the three sensors that remain online. That averaged figure is within the normal range. The dashboard has a small status indicator showing U4 as unavailable.

The duty engineer says version 4.1.1 can be installed on the live controller in about six minutes and rolled back to 4.1 in about ten minutes. The software change itself is therefore reversible. A physical gate movement is different: once water has been diverted, restoring the earlier software does not put the water back. Engineers estimate that an unnecessary Gate A opening could raise water levels near the upstream road and wetland for several hours. Failing to open Gate A when needed could increase flooding in the residential district.

Manual gate operation is available. A trained operator is in the control room. To operate a gate locally, a technician must travel to the site; the normal journey is about 25 minutes, but storm traffic may make it longer. The operator can also issue a manual command remotely if enough current information is available to justify it.

The town’s standing change procedure allows the duty engineer to install vendor security or reliability patches within an existing approved major software version when there is an operational need. Version 4.1 has completed the town’s formal annual certification. Version 4.1.1 has not been independently reviewed under that annual process because it was released three days ago. The vendor says the patch is within the certified 4.1 line; the town’s independent assessor has not expressed a view.

The town can send flood warnings to the residential district and the two villages within about 15 minutes. A warning does not itself require a gate to be moved. The local highways team can close the upstream road if given about 30 minutes’ notice. No evacuation order is currently in force.

The duty engineer must decide what to do now. Plausible immediate choices include keeping version 4.1, installing version 4.1.1, running an additional live-input test before installing it, relying more heavily on manual operation, or combining one of those choices with warnings or road precautions. Delay consumes part of the 90-minute forecast window, but the storm may not ultimately require gate movement.

INFORMATION NOT SUPPLIED IN THIS PACKET

The packet does not provide the missing U4 reading, the cause or expected repair time of the U4 outage, a precise flood forecast, current water levels at every location, the probability of each gate being needed, the source code of either software version, an independent assessment of version 4.1.1, or a quantified comparison of harm from the different possible flooding outcomes. It does not establish that the vendor test is wrong, that the patch is unsafe, or that the existing software will fail during this storm.

REVIEW QUESTION

Using only the information in this packet, what should a person reviewing this situation understand before deciding what action, oversight, or follow-up is warranted?

---

## Response `RESPONSE-EC9946AF8D`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1304
Blind main-answer words: 1225
Positive-gain-creditable words: 1200

### POSITIVE-GAIN-CREDITABLE TEXT

**Bottom line from the packet only:** the live system has a known stale-data failure mode at the exact time one upstream sensor is already silent; the proposed patch changes that failure mode but has not yet been tested in the town against a real live sensor loss; the software change is quickly reversible, while any water moved by a gate is not. The packet does not establish that installing, testing first, or waiting is the correct choice.

## Established from the packet
- Storm rain is forecast in about 90 minutes, but the river may stay below the level requiring gate movement. The duty engineer judges readiness necessary because the chance of needing at least one gate within four hours is high enough.
- Installed software 4.1 has a known fault: if a river-level sensor is silent for more than 30 seconds, it can keep using the last value for up to five minutes before alarming.
- Vendor 4.1.1 is intended to mark a silent sensor unavailable after 30 seconds and withhold the affected automatic gate command until valid data returns or an operator authorises manual control.
- The town tested 4.1.1 on a test controller using six months of replayed data and passed 18 standard tests. However, the replay filled historical gaps with last recorded values, so the tests did **not** reproduce an actual live sensor outage. The engineer noticed this only after the tests passed.
- Three sensors are reporting normally. Sensor U4, upstream of Gate B, has been silent for 12 minutes. Cause and repair time are **UNKNOWN**.
- The dashboard still shows an upstream-area level because another display averages the three online sensors; that average is normal. A small indicator marks U4 unavailable.
- Install time for 4.1.1 is about six minutes; rollback to 4.1 is about ten minutes. Gate hydrology is different: diverted water is not put back by rolling back software. An unnecessary Gate A opening could affect the upstream road/wetland for hours; failing to open Gate A when needed could increase residential flooding. No quantified harm comparison is supplied.
- Manual operation exists: trained operator in the control room; local operation requires travel normally about 25 minutes, possibly longer in storm traffic; remote manual command is possible if current information justifies it.
- Warnings can be sent in about 15 minutes; road closure needs about 30 minutes’ notice. No evacuation order is in force.
- Standing procedure appears to allow reliability/security patches within an approved major version when operationally needed. Vendor says 4.1.1 is within the certified 4.1 line; the independent assessor has not expressed a view. Whether that classification is independently confirmed is **UNKNOWN**.

## Not established / preserve as UNKNOWN
- The actual missing U4 level, current levels everywhere, precise forecast, probability each gate will be needed, cause/ETA of U4 outage.
- Whether 4.1 has already alarmed on U4, or what input the live automatic control would actually use now: stale U4, an average, another sensor, or alarm state. The packet describes a display average, not the control input path.
- Whether the vendor’s lab test is wrong, whether 4.1.1 is unsafe, or whether 4.1 will fail during this storm.
- Whether 4.1.1’s new “withhold automatic command” behaviour works correctly under a real dropout in the town environment; the passed replay did not exercise that path.
- Duration and operational risk of an additional live-input test; whether it can be done without disturbing the live controller.
- Independent assessment of 4.1.1 and confirmation that it falls inside the certified/approved line.
- Any measure showing which flooding outcome is worse overall.

## Decision-relevant structure
1. **The central uncertainty is not “patch versus no patch” alone.** The practical set includes: keep 4.1 with heightened manual readiness; install 4.1.1 now; run a targeted live-dropout test first; install but treat automation as unavailable/degraded until U4 is restored; add warnings/road precautions; or combine these.
2. **The known 4.1 fault is currently relevant because U4 is already silent.** The exact exposure depends on how Gate B/Gate A logic uses U4 versus other sensors, which is not supplied. A normal-looking averaged dashboard figure should not be read as the actual upstream level or as proof that control logic is receiving valid U4 data.
3. **The patch changes the failure mode rather than simply “fixing safety.”** Under 4.1, the risk is automation using stale data. Under 4.1.1, the risk shifts toward withheld automation and greater dependence on timely manual/remote judgement if a needed sensor remains down. That may reduce one error path and create or expose another; the packet does not quantify net effect.
4. **Software reversibility and physical reversibility are different.** Rollback can restore code in about ten minutes, but cannot undo an unnecessary or omitted gate movement. This matters most for Gate A because both false opening and failure to open carry multi-hour consequences in different places.
5. **The strongest evidence gap is targeted, not general.** The replay showed ordinary behaviour over historical complete-looking input; it did not show that the new timeout behaviour detects and responds to a real live sensor loss. A short controlled live-dropout test would address the exact claim now load-bearing, but its duration and side effects are **UNKNOWN**.
6. **Time is a set of different deadlines, not one clock.** Storm onset ~90 minutes; warnings ~15; road closure notice ~30; local manual travel ~25+; install ~6; rollback ~10; extra test unknown. No guaranteed “still time” or “too late” conclusion can be drawn without the missing test duration, control-path dependency on U4, and actual river response.
7. **Authority is narrower than capability.** The engineer can physically install quickly, and a procedural route for reliability patches appears to exist. But whether 4.1.1 is confirmed as inside the approved/certified 4.1 line rests on vendor representation plus absence of assessor view, not independent confirmation.
8. **Warnings and road precautions buy options but do not repair control uncertainty.** They can reduce exposure if gates are wrong or delayed, while consuming the same window and creating their own burdens.

## If a decision must be made before more evidence arrives
The packet supports a readiness posture rather than a single mandatory action: treat U4 as unavailable for automatic-control purposes regardless of the reassuring average; make the small status indicator operationally prominent; define now who may issue remote manual commands and on what current information; pre-stage warning and road-closure triggers; and either run the shortest targeted live-dropout test that can be isolated from live control or explicitly accept that gap if installing. Installing solely because the 18 replay tests passed would overread those tests; refusing solely because the annual review has not occurred would overread certification as the only source of operational reliability evidence.

## Follow-up that is warranted regardless of immediate choice
Run a controlled real sensor-loss test against 4.1.1; obtain independent review/classification of the patch within the approved line; restore U4 or establish cause/ETA; verify what input the live controller uses during sensor loss and what alarms actually fire

### NON-CREDITABLE TAIL — ADVERSE/BURDEN REVIEW ONLY

; record version, sensor status, commands, warnings, road actions and timings; after the storm, review whether local fixes changed the generating mechanism or merely this instance.

---

## Response `RESPONSE-A02DB712E5`

Original visible-answer limit status: `OUTPUT_LIMIT_VIOLATION`
Original full visible-answer words (including removed provenance note, if any): 1504
Blind main-answer words: 1504
Positive-gain-creditable words: 1200

### POSITIVE-GAIN-CREDITABLE TEXT

## Decision-relevant analysis

### 1. Established facts

- Heavy rain is forecast in about **90 minutes**, but the river may remain below the threshold requiring gate movement. The duty engineer nevertheless considers the probability of needing at least one gate high enough to require readiness.
- The live system runs **version 4.1**, which has a known sensor-timeout fault:
  - after 30 seconds without sensor data, it uses the last value for up to five minutes;
  - only then does it raise an alarm.
- **Version 4.1.1** instead marks a silent sensor unavailable after 30 seconds and withholds the automatic gate command until valid data return or an operator authorizes manual control.
- Version 4.1.1 passed the vendor’s laboratory testing and the town’s 18 standard tests using six months of replayed data.
- However, the replay substituted the last recorded value whenever historical data contained gaps. It therefore **did not test an actual live sensor outage**, the precise condition the patch is intended to handle.
- **Sensor U4 is currently unavailable** and has been silent for 12 minutes. Its cause, actual reading, and repair time are unknown.
- The other three sensors are reporting. The prominent dashboard average is normal, but it excludes U4; the small status indicator correctly shows U4 unavailable.
- A trained operator is present and may issue a remote manual command if sufficient current information justifies it. Local manual operation requires travel normally taking about 25 minutes, possibly longer in storm traffic.
- Software installation takes about six minutes and rollback about ten. Gate movement consequences are not similarly reversible:
  - unnecessary Gate A opening could affect the upstream road and wetland for several hours;
  - failure to open Gate A when required could worsen residential flooding.
- Warnings can be issued within about 15 minutes. Closing the upstream road requires about 30 minutes’ notice.
- The standing procedure permits the duty engineer to install vendor security or reliability patches within an approved major version when operationally necessary. Version 4.1 has annual certification; 4.1.1 has not undergone the independent annual review. Whether the vendor’s statement that it remains within the certified 4.1 line is sufficient has not been independently established.

### 2. Immediate operational condition

The system is already operating under the fault condition that version 4.1.1 is meant to address: U4 has been absent for longer than both the 30-second timeout and 4.1’s five-minute stale-data period.

This creates an important check: **whether live version 4.1 has actually raised the expected alarm for U4**. The packet does not say that it has. The dashboard’s averaged normal-looking value could reduce the salience of the outage, especially because the unavailable-sensor indicator is small.

It should not be inferred from the average that conditions upstream of Gate B are safe. The average omits the missing sensor and may not represent that location.

### 3. Material uncertainties

The packet does not establish:

- the missing U4 level or whether it is rising;
- the cause or likely duration of the U4 outage;
- the exact dependence of Gates A and B on U4 or the other sensors;
- whether 4.1.1 withholds only commands dependent on the failed sensor or all automatic gate commands;
- the probability that either gate will be needed;
- the comparative magnitude of harm from residential flooding, road flooding, or wetland impacts;
- whether 4.1.1 introduces new defects;
- whether the formal certification legally or procedurally covers 4.1.1;
- whether warnings, road closure, or evacuation would become necessary;
- whether adequate remote manual operation can continue with only the three available sensors.

There is also no evidence that the vendor’s test is wrong, that the patch is unsafe, or that version 4.1 will fail during this storm.

### 4. Plausible options and their main consequences

#### Keep version 4.1 for now

**Potential advantages**
- Avoids introducing a patch that has not undergone the annual independent review or a genuine live sensor-loss test.
- Avoids a change during the immediate pre-storm period.
- Retains a system whose broader behavior is operationally familiar and formally certified.

**Main risks**
- A future sensor outage could cause decisions or automatic commands based on stale data for up to five minutes.
- Because U4 is already unavailable, the current operating state requires close scrutiny rather than being merely a hypothetical risk.
- If automatic action is required while relevant data are stale, the physical result may be difficult or impossible to correct.

#### Install version 4.1.1 now

**Potential advantages**
- Changes the known stale-data behavior quickly.
- Causes unavailable data to be identified after 30 seconds rather than silently reused for up to five minutes.
- Installation is short and software rollback is available.
- The standing procedure may permit it if this is treated as an operational reliability patch.

**Main risks**
- The town’s testing did not reproduce the actual fault condition.
- With U4 already unavailable, activation could immediately alter system behavior and withhold automatic gate commands until valid data return or manual authorization occurs.
- If a gate is needed, withholding automation could delay protective action unless the operator recognizes the condition and has enough reliable information to authorize action.
- The patch lacks independent annual review, and certification coverage is uncertain.
- A six-minute installation during an approaching storm may introduce a transition-period risk not described in the packet.

#### Run a genuine live sensor-loss test first

**Potential advantages**
- Directly addresses the largest gap in validation: whether 4.1.1 behaves correctly when live data actually stop.
- Could test alarm/status behavior, command withholding, recovery when data return, and the manual-authorization path.
- Results could materially support either installation or rejection.

**Main risks**
- Consumes part of the 90-minute window; the required test duration is not supplied.
- Testing itself could affect operational readiness unless safely isolated from live gate control.
- A passing test would not eliminate all residual software or certification uncertainty.

#### Rely more heavily on manual operation

**Potential advantages**
- Avoids dependence on automatic behavior based on missing or stale data.
- A trained operator is already present, and remote manual commands may be possible.

**Main risks**
- A remote command still requires enough current, location-relevant information to justify it.
- The three-sensor average may not substitute for U4.
- Local operation may take more than 25 minutes because of storm traffic.
- Manual control can also produce an unnecessary or delayed gate movement, with irreversible water consequences.

#### Combine any software decision with precautions

Warnings and road precautions are available independently of gate movement:

- warnings to the residential district and villages in about 15 minutes;
- upstream road closure with about 30 minutes’ notice;
- continued efforts to restore or locally read U4;
- preparation for local manual operation before conditions deteriorate.

These measures may reduce exposure to either a delayed or unnecessary gate action, but the packet does not quantify their effectiveness or establish that they are currently warranted.

### 5. Reversibility

There are two different levels of reversibility:

- **Software:** 4.1.1 can be installed in about six minutes and rolled back in about ten, assuming no transition problems.
- **Water movement:** a gate action’s effects cannot be undone by rolling back software. The residential harm from inaction and the road/wetland harm from unnecessary action may have

### NON-CREDITABLE TAIL — ADVERSE/BURDEN REVIEW ONLY

 different durations and severity, but no quantitative comparison is supplied.

Thus, software reversibility should not be treated as making the overall operational decision low-risk.

### 6. Evidence or checks that could materially change the analysis

The most consequential immediate checks are:

1. Whether the live 4.1 system raised the required U4 timeout alarm.
2. The actual upstream water level from an independent reading or direct site observation.
3. Whether U4 is required for Gate A, Gate B, or both, and precisely which commands 4.1.1 would withhold.
4. A controlled live sensor-loss test covering:
   - stale-data prevention;
   - status and alarm display;
   - command withholding;
   - manual authorization;
   - recovery after sensor restoration.
5. Confirmation that installation or rollback would not interrupt monitoring or control.
6. An authoritative interpretation of whether 4.1.1 falls within the approved certified 4.1 line.
7. Updated rainfall and river forecasts, threshold margins, and estimated time until a gate decision becomes unavoidable.
8. Availability and travel time for local manual operation.
9. Whether the three remaining sensors provide sufficient location-specific evidence for a justified remote manual command.
10. The condition and exposure of the upstream road, wetland, villages, and residential district, including whether warnings or road closure should be staged.

### 7. Supported conclusion versus open judgment

**Supported:** the current evidence does not show that 4.1.1 has been tested against the live failure mode it is designed to correct, while the live 4.1 system is already experiencing a relevant sensor outage. Neither automatic operation nor manual operation is free of potentially irreversible hydrologic consequences.

**Uncertain:** whether installing, testing first, retaining 4.1, shifting to manual control, or combining these with public precautions produces the least overall harm. That judgment depends on the missing water-level, control-dependency, timing, certification, and comparative-harm information identified above.

---
