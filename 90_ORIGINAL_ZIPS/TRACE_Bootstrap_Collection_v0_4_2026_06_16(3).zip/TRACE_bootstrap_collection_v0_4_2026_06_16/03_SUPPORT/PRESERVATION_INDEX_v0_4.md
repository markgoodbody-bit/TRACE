# TRACE Bootstrap Collection Preservation Index v0.4

Generated: 2026-06-16.

Patch type: active-set update adding Groundhog Day as recursion / operational-free-will teaching case. Existing bootstrap PDFs and source markdown are preserved unchanged except for the added Groundhog Day PDF/source.

## Active Bootstrap Set

| No. | Case | Role | Core operators |
|---:|---|---|---|
| 00 | TRACE Rosetta Core v6 FULL | Source core | TRACE contract, grammar, anti-domestication |
| 01 | Memento | Memory / identity | memory bridge, record trust, manipulation risk |
| 02 | Everything Everywhere All At Once | Meaning / state-space | bounded meaning, relation weights, null attractor |
| 03 | Children of Men | Hope / future-space | fragile future carrier, continuity, hope as option-space evidence |
| 04 | Unthinkable | Method under emergency | no-clean-branch, inadmissible methods, constraint floor |
| 05 | Samwise Gamgee | Load-bearing care | carry load not ring, constraint under temptation, care under pressure |
| 06 | Apollo 13 | Positive correction | correction before hardening, live K-gate, distributed repair |
| 07 | Harriet Tubman | Exit under predatory law | exit route, protected circle, protective secrecy, care with teeth |
| 08 | Groundhog Day | Recursion / free will | repeated choice, memory, feedback, self-update, escape condition |

## New v0.4 Primitive

```trace
recursive_agency :=
  repeated_branch_selection
  + memory
  + feedback
  + self_update
  under_constraint

free_will_operational :=
  selection_that_changes_the_future_selector
```

## Drift Guard

```trace
if Groundhog_Day -> proof_of_free_will:
  fail

if recursion -> guaranteed_moral_progress:
  fail

if other_subject -> training_object:
  fail

if Mandelbrot -> decorative_metaphor_only:
  fail
```

## Current Rule

Groundhog Day is a teaching case that maps recursion and operational free will. It does not validate TRACE and does not replace Rosetta v6 FULL.
