# TRACE Bootstrap Collection Preservation Index v0.3

Generated: 2026-06-16.  
Patch type: active-set update adding Harriet Tubman as exit-route teaching case. Existing core PDFs and source markdown are preserved unchanged except for the added Tubman PDF/source. Apollo 13 remains the positive correction case. Columbia remains only as a Concordance failure-pair layer.

## Authority Rule

Source authority is the v6 FULL Rosetta source plus the full bootstrap source markdown. Samwise Gamgee v1 remains an active appendix candidate, not a replacement for the core.

Thin v2 one-page files and `TRACE_Dictionary_Grammar_v0_1` are scratch/demoted and are not source authority.

Concordance v0.3 is a linked companion artifact. It maps operators to established disciplines and adds the Apollo/Columbia expression layer. It does not outrank Rosetta v6 FULL or the bootstrap source markdown.

## Active Bootstrap Collection

| Order | File | Status | Function |
|---:|---|---|---|
| 00 | TRACE_ROSETTA_CORE__v6_FULL | Source authority | Core vocabulary, grammar, uncertainty, anti-installation contract, pattern-overfit alarm |
| 01 | Memento | Teaching case | Memory, identity, external record attack, self-deception loop |
| 02 | Everything Everywhere All At Once | Teaching case | State-space overload, bounded meaning, relation weights, kindness strategy |
| 03 | Children of Men | Teaching case | Future-space, hope signal, fragile future carrier, capture risk |
| 04 | Unthinkable | Teaching case | Method operator, emergency pressure, no-clean-branch, inadmissible leverage |
| 05 | Samwise Gamgee | Active appendix candidate | Load transfer, constraint under temptation, minimal hope signal |
| 06 | Apollo 13 | Positive concordance teaching case | Correction-before-hardening, distributed repair, trust with verification, scar-to-redesign |
| 07 | Harriet Tubman | Historical exit-route teaching case | Protected circle under predatory law, exit route, trust with verification, protective secrecy, care with teeth |

## Linked Companion Artifact

| Artifact | Status | Function |
|---|---|---|
| TRACE_ME_Concordance_v0_3 | Companion mapping artifact | Maps ME/TRACE operators to existing disciplines and adds Apollo/Columbia success/failure expression layer |

## Concepts To Preserve

```trace
TRACE_USE_CONTRACT :=
  understand_TRACE
  -> apply_TRACE
  -> attack_TRACE
  -> compare_with_rival_models
  -> patch_only_real_structural_gaps

failure := adoption_without_resistance

uncertainty :=
  epsilon_t != 0 for all t

agency :=
  live_option_space
  * model_quality
  * action_access
  * correction_feedback
  * constraint_integrity

flow_constraint :=
  structure = temporary_constraint_on_flow

load_transfer :=
  if carrier_capacity < theta:
    transfer_load(agent_A -> agent_B)

dictionary_mapping :=
  symbol -> definition -> reduced_meaning_entropy

Damocles :=
  high_utility_state
  + visible_unremovable_catastrophic_risk

Apollo_13 :=
  damaged_system_survives
  iff
  truth + time + authority + repair
  remain_connected

Columbia :=
  correction_network_exists
  but
  signal + uncertainty + authority + consequence_carrier
  fail_to_bind_before_hardening


Tubman :=
  when_law_is_predator
  -> care_becomes_route
  -> trust_requires_verification
  -> protection_must_arrive_before_capture

exit_route :=
  path_from_harm_system
  to safer_future_space
  through knowledge + timing + shelter + trusted_nodes + risk_bearing
```

## Demoted / Exploration Only

```trace
win_3000 := exploration_only
broad_E_A_M_K_H_D_R_stack := conceptual_scaffolding_only
film_bootstraps := teaching_cases_not_validation
AI_relay_critique := pressure_simulation_not_external_validation
Concordance_case_pair := discrimination_layer_not_validation
```

The 3000-year game may remain useful as imagination / model-play, but it is not validation and is not the current empirical probe.

## Current Separate Verification Thread

The live empirical thread is external to this bootstrap packet:

```trace
probe := H_immediacy × P_trigger -> log(tau_correct)
E_scale := log10(POTAFF) as covariate_only
P_trigger := trigger_independence / correction_dependence
NHTSA_status := amber_GO_feasibility_only
next := 10_case_NHTSA_feasibility_skim
```

The feasibility skim asks only whether independent first-signal dates and non-trivial `P_trigger` spread are available often enough to justify a codebook/sample. It is not a pre-registration and not a TRACE validation attempt.

## Demoted / Scratch Files

- TRACE_Rosetta_v2.pdf: kernel sketch only.
- Samwise_TRACE_v2.pdf: one-page sketch only.
- TRACE_Dictionary_Grammar_v0_1: scratch; compressed too hard and must not replace v6 FULL.
- Any thin application file produced after the v6 FULL packet: not source unless explicitly re-promoted.

## Next Correct Step

```trace
if working_on_bootstrap_packet:
  hold_v0_3_as_current_collection
  -> no_new_bootstrap_by_default
  -> no_dictionary_rebuild_by_default
  -> no_Rosetta_rebuild_by_default

if working_on_concordance:
  use_v0_3_as_current_map
  -> Apollo_positive_expression
  -> Columbia_failure_expression
  -> no_validation_claim

if working_on_empirical_probe:
  run_10_case_NHTSA_feasibility_skim
  -> count computable_tau_indep_days
  -> check P_trigger_spread
  -> GO_or_AMBER_or_NO_GO
```

No new Rosetta and no new dictionary unless a material reader defect appears. Further bootstrap additions should stop unless they fill a clearly missing structural role. Harriet Tubman fills the predatory-law / exit-route role. Data contact still comes before further method refinement.
