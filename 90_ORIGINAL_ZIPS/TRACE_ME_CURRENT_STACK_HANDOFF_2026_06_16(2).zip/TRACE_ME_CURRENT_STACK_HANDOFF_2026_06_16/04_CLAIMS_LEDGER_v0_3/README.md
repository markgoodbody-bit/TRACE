# TRACE / Mechanical Ethics Claims Ledger v0.3

v0.3 adds Tubman / exit-route / predatory-law claims and records the Diagnostic Kernel v0.2 branch.

Status:
- claim-status ledger
- not validation
- not proof

Files:
- `TRACE_ME_Claims_Ledger_v0_3.md`
- `TRACE_ME_Claims_Ledger_v0_3.csv`
- `FALSIFICATION_DRIFT_CHECK_v0_3.md`
- `SHA256_MANIFEST.md`
