# TRACE / Mechanical Ethics Claims Ledger v0.3

Date: 2026-06-16  
Status: claim-status ledger; not validation; not proof.

## Change from v0.2

v0.3 adds Tubman / exit-route / predatory-law claims and records the Diagnostic Kernel v0.2 branch.

## New v0.3 Claims

| ID | Claim | Status | Source / comparator | ME / TRACE remainder | Falsifier / demoter | Must not claim |
|---|---|---|---|---|---|---|
| T041 | Legality is not identical to legitimacy; a lawful system can be the harm carrier. | known_patterned_boundary | Abolitionism, human rights, civil disobedience traditions; Harriet Tubman bootstrap. | Turns the distinction into an operational branch: internal correction may fail if the legal channel enforces the harm. | Demote if used to imply all law is predatory or to bypass corrigible due process without evidence. | Do not claim all institutions are illegitimate or that legality never matters. |
| T042 | When the official correction channel is itself dangerous or captured, the diagnostic question must include exit route and external constraint. | patterned_operator | Harriet Tubman bootstrap; sanctuary/resistance traditions; witness-protection and emergency safeguarding analogues. | Adds Exit-Route Branch to Diagnostic Kernel v0.2. | Demote if exit-route language becomes metaphorical, reckless, or detached from practical subject protection. | Do not claim exit is always possible or always superior to internal correction. |
| T043 | Secrecy can be ethically protective when visibility would serve the predator, but secrecy is dangerous when it shields power from accountability. | hypothesis_boundary | Harriet Tubman bootstrap; clandestine resistance; witness protection; security studies. | Creates protective-secrecy exception to ordinary witness/record visibility preference. | If secrecy protects the powerful from review or hides harm from subjects, it fails the exception. | Do not treat opacity as generally good. |
| T044 | Care with teeth means option-space restoration under constraint, not sentiment alone. | patterned | Care ethics, liberation ethics, Samwise bootstrap, Harriet Tubman bootstrap. | Links care to route, burden-bearing, verification, and practical future-space preservation. | Demote if the phrase becomes motivational rhetoric without operational consequence. | Do not reduce care to rescue fantasy or savior mythology. |
| T045 | The Diagnostic Kernel must branch between internal correction and exit/protection when the system type changes. | artifact_design_claim | Diagnostic Kernel v0.2; Tubman bootstrap; Concordance v0.4. | Keeps K-gate from assuming corrigibility in predatory systems. | If the branch confuses users or encourages overclassification of systems as predatory, simplify or demote. | Do not claim this branch is a general political theory. |


## Full Ledger

| ID | Claim | Status | Source / comparator | ME / TRACE remainder | Falsifier / demoter | Must not claim |
|---|---|---|---|---|---|---|
| C01 | A compact model or glyph can organise attention without proving the represented structure. | KNOWN | General modelling / scientific-method boundary; Concordance v0.3: model != measurement, compression != proof. |  | Any artifact uses elegance/compression as evidence of truth. | Not claiming notation validates ME/TRACE. |
| C02 | A correction path can be formally present but functionally late. | PATTERNED | Administrative justice, due process, system-safety postmortems; Diagnostic Kernel v0.1. |  | Cases where formal availability reliably prevents hardening without timing constraints. | Not claiming every late process is malicious or illegal. |
| C03 | The minimum useful correction question is: can correction reach the affected subject before harm hardens? | PATTERNED | Diagnostic Kernel v0.1; Apollo/Columbia concordance layer. |  | If the question fails to discriminate live cases better than ordinary prose. | Not claiming this is a complete ethics theory. |
| C04 | Correction is conjunctive: witness, record, authority, time, enforcement, and repair can fail if any essential carrier is absent. | PATTERNED | K-gate / reliability engineering / due process / cybernetics; Diagnostic Kernel v0.1. |  | If real cases show missing factors do not materially affect correction capacity. | Not claiming the exact six factors are final or exhaustive. |
| C05 | Unknowns must not be silently converted into passes. | KNOWN | Risk governance, audit practice, safety engineering; Diagnostic Kernel boundary. |  | If treating unknown as pass improves safety without hidden harm. | Not claiming every unknown requires shutdown. |
| C06 | A pass through the Diagnostic Kernel is not a safety certification. | KNOWN | Kernel v0.1 boundary. |  | If artifacts begin using kernel pass as proof of safety/alignment. | Not claiming the kernel replaces expert review. |
| C07 | Correction-fragility increases when the actor causing or controlling harm also controls the correction trigger. | PATTERNED | Institutional economics, administrative law, capture theory; P_trigger field. |  | If actor-controlled systems routinely correct faster than independent systems under comparable stakes. | Not claiming actor-control always implies bad faith. |
| C08 | High hazard immediacy raises the importance of live correction because hardening arrives faster. | KNOWN/PATTERNED | Safety engineering, product safety, emergency response; H_immediacy field. |  | If slow correction routinely suffices for immediate-catastrophic hazards without compensating safeguards. | Not claiming all high-immediacy systems are unacceptable. |
| C09 | The narrow empirical probe is H_immediacy × P_trigger -> log(tau_correct). | HYPOTHESIS | NHTSA feasibility thread; Claude/Framework relay. |  | If interaction is null/negative with adequate independent first-signal data, or P collapses. | Not claiming validation; not even preregistered yet. |
| C10 | E_scale / units affected is a covariate only in the minimal NHTSA probe. | HYPOTHESIS-BOUNDARY | NHTSA methods triage. |  | If later domain shows scale is the actual interaction, move to secondary test. | Not claiming scale is unimportant. |
| C11 | NHTSA is amber until independent first-signal dates are shown feasible. | HYPOTHESIS-BOUNDARY | NHTSA feasibility notes; Part 573 / ODI issue. |  | If 10-case skim cannot find independent signals or P spread, demote NHTSA. | Not claiming NHTSA data are unusable generally. |
| C12 | Manufacturer-authored chronologies can create differential measurement error in tau_correct if they compress knew-to-acted gaps. | HYPOTHESIS/RISK | Claude methods triage; Part 573 authoring concern. |  | If independent ODI signals align with manufacturer chronologies across hard cells. | Not claiming all manufacturers distort chronologies. |
| C13 | The 3000-year civilisation game is exploration only. | EXPLORATION-DEMOTED | Claude/Framework relay; memory update. |  | If used as validation or causal proof, demote output. | Not claiming the broad stack predicts civilisations. |
| C14 | The broad E/A/M/K/H/D/R stack is conceptual scaffolding, not a validated model. | EXPLORATION-DEMOTED | Claude/Framework relay. |  | If it becomes a claim engine without external checks. | Not claiming these variables are useless. |
| C15 | The Concordance is strongest when it maps ME/TRACE operators to established counterparts and isolates any remainder. | PATTERNED | Concordance v0.3. |  | If mappings are inaccurate, forced, or omit obvious prior art. | Not claiming ME invented mapped concepts. |
| C16 | The ME/TRACE remainder is currently narrow: clocked, conjunctive correction before hardening under power/trigger dependence. | HYPOTHESIS-READY | Concordance v0.3; Kernel v0.1; NHTSA probe. |  | If ordinary frameworks explain all useful work with no remainder. | Not claiming a complete new field. |
| C17 | Apollo 13 is a positive illustration of correction beating hardening, not proof of TRACE. | ILLUSTRATION | Bootstrap Collection v0.2.1; Concordance v0.3 Apollo layer. |  | If used alone as validation or selected-example proof. | Not claiming NASA was structurally safe before the accident. |
| C18 | Columbia is a paired failure illustration: signal/process existed but correction did not bite before hardening. | ILLUSTRATION | Concordance v0.3 Columbia layer; CAIB anchor in artifact. |  | If it becomes a claim that rescue was simple/certain. | Not claiming the pair validates TRACE empirically. |
| C19 | The Apollo/Columbia pair is useful only because it maps operators to different outcomes. | PATTERNED | Concordance v0.3 case-pair layer. |  | If pair analysis collapses into hindsight narration with no discriminating rows. | Not claiming hand-picked cases establish generality. |
| C20 | Film/history bootstraps are teaching cases, not stress tests or validation. | KNOWN-BOUNDARY | Bootstrap Collection v0.2.1 README / preservation index. |  | If future bootstraps are selected to break the model and can actually falsify operators. | Not claiming stories are useless. |
| C21 | TRACE can orient a reader but cannot certify its own critic. | KNOWN-BOUNDARY | Claude/Framework domestication critique. |  | If an independent external reader can reject/use/misunderstand the work in ways that alter it. | Not claiming internal review has no value. |
| C22 | Internal AI relay critique is pressure simulation, not external validation. | KNOWN-BOUNDARY | Relay identity headers; memory update. |  | If the project starts presenting AI convergence as proof. | Not claiming AI critique is worthless. |
| C23 | Mechanistic interpretability and Mechanical Ethics are adjacent but not identical. | PATTERNED | Campfire framing; MI = internal mechanisms, ME = external constraints/permission structure. |  | If MI alone can guarantee timely corrigibility at deployment boundary. | Not claiming MI is unimportant. |
| C24 | AI alignment needs constraints on action and correction channels, not only value statements. | PATTERNED | AI safety/corrigibility lineage; ME campfire frame. |  | If value-learning or preference alignment alone reliably prevents irreversible harm. | Not claiming values are irrelevant. |
| C25 | Kindness with teeth means protective cooperation plus enforceable resistance to exploitation or hidden harm. | PATTERNED | Concordance v0.3; project anchor. |  | If “teeth” become coercive domination or “kindness” becomes symbolic softness. | Not claiming a full moral theory. |
| C26 | Trust with verification is stronger than trust alone or suspicion alone. | KNOWN/PATTERNED | Safety, audit, operational security, governance. |  | If verification destroys all workable trust or trust without verification performs better under stakes. | Not claiming all relationships should be surveilled. |
| C27 | Power/capability can move faster than correction, creating a structural risk gap. | PATTERNED | Control theory, governance, AI safety, institutional failure. |  | If high-capability systems routinely include proportionately faster independent correction. | Not claiming power is inherently bad. |
| C28 | A safeguard is not real unless it can bite in time. | PATTERNED | Safety engineering, enforcement theory, project artifacts. |  | If non-binding safeguards reliably prevent hardening under adversarial/pressured conditions. | Not claiming every safeguard must be punitive. |
| C29 | Safeguards themselves require safeguards when they become power paths. | CANDIDATE DISTINCTIVE | Recursive brake / frontier AI governance artifact; Concordance v0.3. |  | If first-order safeguards can be trusted without review even under power concentration. | Not claiming infinite regress; needs bounded stopping rules. |
| C30 | Future-space collapse is a useful harm compression but not yet a mature measure. | PATTERNED/HYPOTHESIS | Rosetta / Concordance; future-space operator. |  | If it cannot be operationalised beyond metaphor. | Not claiming all harms reduce cleanly to option-space. |
| C31 | Hope signal means credible evidence that action still matters, not comfort language. | PATTERNED | Children of Men bootstrap lineage; Concordance row. |  | If hope language substitutes for actual option preservation. | Not claiming optimism is evidence. |
| C32 | Pattern-overfit alarm is mandatory: if TRACE explains everything, demote it. | KNOWN-BOUNDARY | Rosetta / Concordance failure mode. |  | If operators cannot name a possible fail case. | Not claiming the alarm is sufficient by itself. |
| C33 | Claims Ledger is needed because global “is it validated?” doubt is too blunt. | PATTERNED | Current artifact strategy. |  | If the ledger becomes a shield against criticism rather than a status map. | Not claiming status tags are proof. |
| C34 | The Diagnostic Kernel is useful only if it remains one-page and runnable. | PATTERNED | Kernel v0.1 design constraint. |  | If real use requires many hidden rules/caveats. | Not claiming minimalism solves all cases. |
| C35 | The Concordance should reduce private-symbol dependence. | PATTERNED | Concordance v0.3 purpose. |  | If readers still need the whole private corpus to understand it. | Not claiming glyph layer is useless. |
| C36 | Artifact building is legitimate exploratory modelling when it records status and avoids validation claims. | PATTERNED | Mark campfire correction; project discipline. |  | If artifacts replace data contact indefinitely while claiming progress against reality. | Not claiming building equals validation. |
| R037 | TRACE is currently strongest as a diagnostic/design checklist and training/orientation framework. | review_supported_pattern | Copilot review; Gemini review; Claude artifact strategy; internal Kernel/Concordance stack. | Makes time, memory, method, uncertainty, and correction-before-hardening inspectable in one compact checklist. | If users cannot apply the Kernel to real cases without confusion or if ordinary incident-review checklists cover the same work with less distortion, demote to teaching vocabulary. | Do not claim TRACE is validated or superior to expert review. |
| R038 | TRACE is not yet a prescriptive governance tool without operational definitions, thresholds, authority mapping, and empirical anchors. | known_limitation | Copilot review; prior NHTSA feasibility discussion; Diagnostic Kernel status guard. | Identifies what must be operationalised before governance use: clocks, K-factors, authority, enforcement, repair. | If a domain-specific operationalisation with measurement rules and governance roles is built and survives pilot use, revise this limitation for that domain only. | Do not use TRACE as a scoring/certification system without measurement rules. |
| R039 | The bootstrap cases are legible to external AI readers as teaching cases. | comprehension_signal_not_validation | Gemini review; Copilot review; Claude review of Apollo/Tubman collection. | Bootstraps can communicate operators like K-gate, correction-before-hardening, exit routes, and anti-domestication. | If fresh readers misread bootstraps as validation, proof, or mythic belief system, strengthen status labels or demote bootstraps to private teaching notes. | Do not claim teaching-case legibility validates TRACE. |
| R040 | AI review convergence is useful as comprehension, drift, and weakness signal, but not as external validation. | boundary_claim | Claude anti-domestication critique; Framework review digest; relay discipline. | Preserves value of AI pressure while blocking the internal-validation loop. | If the project begins citing AI agreement as validation, this boundary has failed and review digest should be marked contaminated. | Do not treat Copilot, Gemini, Claude, or Framework agreement as proof of external value. |
| T041 | Legality is not identical to legitimacy; a lawful system can be the harm carrier. | known_patterned_boundary | Abolitionism, human rights, civil disobedience traditions; Harriet Tubman bootstrap. | Turns the distinction into an operational branch: internal correction may fail if the legal channel enforces the harm. | Demote if used to imply all law is predatory or to bypass corrigible due process without evidence. | Do not claim all institutions are illegitimate or that legality never matters. |
| T042 | When the official correction channel is itself dangerous or captured, the diagnostic question must include exit route and external constraint. | patterned_operator | Harriet Tubman bootstrap; sanctuary/resistance traditions; witness-protection and emergency safeguarding analogues. | Adds Exit-Route Branch to Diagnostic Kernel v0.2. | Demote if exit-route language becomes metaphorical, reckless, or detached from practical subject protection. | Do not claim exit is always possible or always superior to internal correction. |
| T043 | Secrecy can be ethically protective when visibility would serve the predator, but secrecy is dangerous when it shields power from accountability. | hypothesis_boundary | Harriet Tubman bootstrap; clandestine resistance; witness protection; security studies. | Creates protective-secrecy exception to ordinary witness/record visibility preference. | If secrecy protects the powerful from review or hides harm from subjects, it fails the exception. | Do not treat opacity as generally good. |
| T044 | Care with teeth means option-space restoration under constraint, not sentiment alone. | patterned | Care ethics, liberation ethics, Samwise bootstrap, Harriet Tubman bootstrap. | Links care to route, burden-bearing, verification, and practical future-space preservation. | Demote if the phrase becomes motivational rhetoric without operational consequence. | Do not reduce care to rescue fantasy or savior mythology. |
| T045 | The Diagnostic Kernel must branch between internal correction and exit/protection when the system type changes. | artifact_design_claim | Diagnostic Kernel v0.2; Tubman bootstrap; Concordance v0.4. | Keeps K-gate from assuming corrigibility in predatory systems. | If the branch confuses users or encourages overclassification of systems as predatory, simplify or demote. | Do not claim this branch is a general political theory. |

## v0.3 Drift Guard

```trace
if Tubman -> generic_bravery:
  fail

if predatory_law_boundary -> all_law_bad:
  fail

if protective_secrecy -> opacity_permission:
  fail

if exit_route -> reckless_escape_metaphor:
  fail

if Kernel_branch -> validation_claim:
  fail
```

Correct use:

```trace
Tubman_delta
  -> status_tagged_claims
  -> Kernel_branch
  not:
    ideology
```
