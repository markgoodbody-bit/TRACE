# TRACE / Mechanical Ethics Case Atlas v0.2

Exploratory case-comparison atlas.

v0.2 replaces the narrow "Failure-Mode Atlas" framing with a broader Case Atlas because the case set now includes:
- success case,
- failure pair,
- exit-route case,
- administrative failures.

Files:
- `TRACE_ME_Case_Atlas_v0_2.md`
- `TRACE_ME_Case_Atlas_v0_2.csv`
- `FALSIFICATION_DRIFT_CHECK_v0_2.md`
- `SHA256_MANIFEST.md`

Status:
- exploratory comparison layer
- not validation
- not proof
