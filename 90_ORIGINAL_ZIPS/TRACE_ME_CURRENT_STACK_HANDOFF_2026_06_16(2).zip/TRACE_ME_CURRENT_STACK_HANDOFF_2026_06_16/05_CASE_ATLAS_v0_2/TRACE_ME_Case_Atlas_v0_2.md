# TRACE / Mechanical Ethics Case Atlas v0.2

Date: 2026-06-16  
Authoring context: Mark Goodbody with Framework (GPT-5.5 Thinking / OpenAI).  
Status: exploratory case-comparison atlas; not validation; not proof.

## Why v0.2 Exists

`Failure-Mode Atlas v0.1` was useful, but the label was too narrow after the Harriet Tubman bootstrap.

The case set now contains:

```trace
success_case := Apollo_13
failure_pair := Columbia
exit_route_case := Harriet_Tubman
administrative_failures := Robodebt + Horizon + Toeslagen
```

So v0.2 is a **Case Atlas**, not merely a failure atlas.

## Core Question

```trace
Can correction_or_exit reach the affected subject before harm hardens?
```

The key branch comes from Diagnostic Kernel v0.2:

```trace
if system_corrigible:
  test_internal_correction_before_hardening

if official_system_is_harm_carrier:
  test_exit_route_before_capture
```

## Case Summary

| ID | Case | Class | Branch | Clock result | Core pattern |
|---|---|---|---|---|---|
| C01 | Apollo 13 | success_after_latent_wound | internal_correction | correction_before_hardening | Correction network bites in time after latent design/test wound becomes emergency. |
| C02 | Space Shuttle Columbia | failure_pair | internal_correction | hardening_before_correction | Correction network exists but does not bind the path before re-entry hardens the harm. |
| C03 | Harriet Tubman / Underground Railroad | exit_route_under_predatory_law | exit_route | exit_before_capture_hardening | When legality is predatory, correction requires exit route, protective secrecy, trusted network, and care with teeth. |
| C04 | Robodebt | administrative_failure | internal_correction_failed | hardening_before_correction | Mass administrative debt system routed consequences faster than correction could bind the institution. |
| C05 | Post Office Horizon | record_authority_failure | internal_correction_failed | hardening_before_correction | Machine records gained practical authority while correction, disclosure, and redress failed for years. |
| C06 | Dutch childcare allowance / Toeslagenaffaire | rule_of_law_failure | internal_correction_failed | hardening_before_correction | Rigid anti-fraud enforcement created severe harm while proportional correction arrived late. |

## Full Case Records

### C01 — Apollo 13

**Class:** success_after_latent_wound  
**Domain:** aerospace / mission control  
**Branch:** `internal_correction`  
**System type:** corrigible technical system under emergency  
**Clock result:** `correction_before_hardening`

**Core pattern:** Correction network bites in time after latent design/test wound becomes emergency.

| Kernel field | Assessment |
|---|---|
| Witness | YES |
| Record | YES |
| Authority | YES |
| Time | YES_NARROW |
| Enforcement | YES |
| Repair / Exit | REPAIR |

**Context flags:**  
H_immediacy: `4`  
P_trigger: `1`  
E_scale: `high consequence / low population scale`

**Single failure point:** latent system wound discovered only after mission damage

**Single repair or route:** ground-crew distributed repair using available materials and executable instructions

**Lesson:** A system can survive catastrophic disturbance if witness, record, authority, time, enforcement, and repair remain connected.

**Must not claim:** Do not claim NASA was structurally safe before the accident.

### C02 — Space Shuttle Columbia

**Class:** failure_pair  
**Domain:** aerospace / organizational safety  
**Branch:** `internal_correction`  
**System type:** corrigible-in-principle institution with non-biting safety channel  
**Clock result:** `hardening_before_correction`

**Core pattern:** Correction network exists but does not bind the path before re-entry hardens the harm.

| Kernel field | Assessment |
|---|---|
| Witness | PARTIAL |
| Record | PARTIAL |
| Authority | FAIL |
| Time | FAIL |
| Enforcement | FAIL |
| Repair / Exit | FAIL |

**Context flags:**  
H_immediacy: `4`  
P_trigger: `3`  
E_scale: `high consequence / low population scale`

**Single failure point:** uncertainty and engineering concern did not become binding authority action

**Single repair or route:** none reached before re-entry

**Lesson:** Existing process is not enough; a safety channel must bite in time.

**Must not claim:** Do not reduce the case to individual error or foam alone.

### C03 — Harriet Tubman / Underground Railroad

**Class:** exit_route_under_predatory_law  
**Domain:** slavery / abolition / resistance network  
**Branch:** `exit_route`  
**System type:** official system is harm carrier  
**Clock result:** `exit_before_capture_hardening`

**Core pattern:** When legality is predatory, correction requires exit route, protective secrecy, trusted network, and care with teeth.

| Kernel field | Assessment |
|---|---|
| Witness | PROTECTIVE_WITNESS |
| Record | PROTECTIVE_SECRECY |
| Authority | EXTERNAL/NETWORK |
| Time | YES_DANGEROUS |
| Enforcement | ROUTE_DISCIPLINE |
| Repair / Exit | EXIT |

**Context flags:**  
H_immediacy: `4`  
P_trigger: `3`  
E_scale: `high human stakes / network scale`

**Single failure point:** official law and enforcement preserve the harm

**Single repair or route:** clandestine route to safer future-space through trusted nodes

**Lesson:** If the official system is the predator, the diagnostic must test exit and protection, not only internal review.

**Must not claim:** Do not romanticize slavery or turn Tubman into a generic bravery symbol.

### C04 — Robodebt

**Class:** administrative_failure  
**Domain:** welfare administration / automated debt  
**Branch:** `internal_correction_failed`  
**System type:** institutional correction slow / burden routed downward  
**Clock result:** `hardening_before_correction`

**Core pattern:** Mass administrative debt system routed consequences faster than correction could bind the institution.

| Kernel field | Assessment |
|---|---|
| Witness | PARTIAL/FAIL |
| Record | PARTIAL |
| Authority | FAIL |
| Time | FAIL |
| Enforcement | FAIL_SYSTEM/YES_SUBJECT |
| Repair / Exit | LATE_REPAIR |

**Context flags:**  
H_immediacy: `3`  
P_trigger: `3`  
E_scale: `mass administrative scale`

**Single failure point:** institutional correction did not bite before financial and psychological harm hardened

**Single repair or route:** refunds/redress after years, not live correction

**Lesson:** Formal contestability is insufficient if burden and consequence arrive faster than correction.

**Must not claim:** Do not treat every automated welfare process as Robodebt.

### C05 — Post Office Horizon

**Class:** record_authority_failure  
**Domain:** IT system / prosecution / institutional accountability  
**Branch:** `internal_correction_failed`  
**System type:** computer record treated as authority over subject evidence  
**Clock result:** `hardening_before_correction`

**Core pattern:** Machine records gained practical authority while correction, disclosure, and redress failed for years.

| Kernel field | Assessment |
|---|---|
| Witness | FAIL |
| Record | FAIL |
| Authority | FAIL |
| Time | FAIL |
| Enforcement | FAIL_SYSTEM/YES_SUBJECT |
| Repair / Exit | LATE_REPAIR |

**Context flags:**  
H_immediacy: `3`  
P_trigger: `3`  
E_scale: `large organizational scale`

**Single failure point:** record authority became non-contestable in practice

**Single repair or route:** appeal/redress after severe hardening

**Lesson:** A record that cannot be meaningfully challenged can become a harm carrier.

**Must not claim:** Do not claim the ledger alone explains the scandal.

### C06 — Dutch childcare allowance / Toeslagenaffaire

**Class:** rule_of_law_failure  
**Domain:** tax-benefit administration / anti-fraud policy  
**Branch:** `internal_correction_failed`  
**System type:** formal legality without proportional subject protection  
**Clock result:** `hardening_before_correction`

**Core pattern:** Rigid anti-fraud enforcement created severe harm while proportional correction arrived late.

| Kernel field | Assessment |
|---|---|
| Witness | FAIL |
| Record | PARTIAL/FAIL |
| Authority | FAIL |
| Time | FAIL |
| Enforcement | FAIL_SYSTEM/YES_SUBJECT |
| Repair / Exit | LATE_REPAIR |

**Context flags:**  
H_immediacy: `3`  
P_trigger: `3`  
E_scale: `mass administrative scale`

**Single failure point:** all-or-nothing rule and institutional framing overwhelmed proportional correction

**Single repair or route:** compensation/recognition after prolonged harm

**Lesson:** The protected circle can shrink under anti-fraud pressure unless correction and proportionality bite early.

**Must not claim:** Do not reduce the case to algorithmic risk alone.

## Drift Guards

```trace
if case_coding -> validation_claim:
  fail

if Apollo -> proof_of_TRACE:
  fail

if Tubman -> generic_bravery_symbol:
  fail

if exit_route -> all_systems_are_predatory:
  fail

if failure_cases -> all_institutions_bad:
  fail
```

Correct use:

```trace
Case_Atlas :=
  comparison_layer
  + training_orientation
  + Kernel_pressure_surface
  not:
    proof
```

## Next Possible Use

Use this atlas to run Diagnostic Kernel v0.2 on one case in detail. Do not keep adding cases unless the new case fills a missing structural role.
