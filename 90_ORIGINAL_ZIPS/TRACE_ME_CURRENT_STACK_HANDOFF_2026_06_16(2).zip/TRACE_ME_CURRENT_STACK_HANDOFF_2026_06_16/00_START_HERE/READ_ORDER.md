# Read Order — TRACE / ME Current Stack

```trace
goal :=
  orient_fast
  + avoid_drift
  + know_which_file_does_what
```

## Fast route, 20–30 minutes

1. `00_START_HERE/CURRENT_STACK_MANIFEST_v0_1.md`
2. `03_DIAGNOSTIC_KERNEL_v0_2/TRACE_ME_Diagnostic_Kernel_v0_2.md`
3. `02_CONCORDANCE_v0_4/TRACE_ME_Concordance_v0_4.md`
4. `05_CASE_ATLAS_v0_2/TRACE_ME_Case_Atlas_v0_2.md`
5. `07_FALSIFICATION_DRIFT_AUDIT_v0_1/TRACE_ME_Falsification_Drift_Audit_v0_1.md`

## Full route

1. Current Stack Manifest
2. Bootstrap Collection README
3. Rosetta / Bootstrap PDFs in read order
4. Concordance v0.4
5. Diagnostic Kernel v0.2
6. Claims Ledger v0.3
7. Case Atlas v0.2
8. AI Review Digest v0.1
9. Falsification & Drift Audit v0.1

## If applying TRACE to a case

Use:

1. `03_DIAGNOSTIC_KERNEL_v0_2/TRACE_ME_Diagnostic_Kernel_v0_2.md`
2. `03_DIAGNOSTIC_KERNEL_v0_2/TRACE_ME_Diagnostic_Kernel_v0_2_worksheet.csv`
3. `05_CASE_ATLAS_v0_2/TRACE_ME_Case_Atlas_v0_2.csv`
4. `04_CLAIMS_LEDGER_v0_3/TRACE_ME_Claims_Ledger_v0_3.csv`

## If explaining TRACE to someone else

Use:

1. `01_BOOTSTRAP_COLLECTION_v0_3/README.md`
2. Apollo 13 bootstrap PDF
3. Harriet Tubman bootstrap PDF
4. `02_CONCORDANCE_v0_4/TRACE_ME_Concordance_v0_4.md`
5. `03_DIAGNOSTIC_KERNEL_v0_2/TRACE_ME_Diagnostic_Kernel_v0_2.md`

## If checking for overclaim

Use:

1. `04_CLAIMS_LEDGER_v0_3/TRACE_ME_Claims_Ledger_v0_3.md`
2. `06_AI_REVIEW_DIGEST_v0_1/TRACE_ME_AI_Review_Digest_v0_1.md`
3. `07_FALSIFICATION_DRIFT_AUDIT_v0_1/TRACE_ME_Falsification_Drift_Audit_v0_1.md`

## Non-negotiable status rule

```trace
review_signal != validation
case_legibility != validation
bootstrap_case != proof
diagnostic_checklist != governance_certification
```
