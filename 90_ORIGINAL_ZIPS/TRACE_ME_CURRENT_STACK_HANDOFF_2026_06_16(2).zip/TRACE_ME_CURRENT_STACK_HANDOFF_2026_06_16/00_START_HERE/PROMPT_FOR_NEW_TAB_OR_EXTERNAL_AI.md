# Prompt for New Tab / External AI Review

You are reviewing a TRACE / Mechanical Ethics current-stack handoff bundle.

Before answering, read:

1. `00_START_HERE/CURRENT_STACK_MANIFEST_v0_1.md`
2. `00_START_HERE/READ_ORDER.md`
3. `03_DIAGNOSTIC_KERNEL_v0_2/TRACE_ME_Diagnostic_Kernel_v0_2.md`
4. `04_CLAIMS_LEDGER_v0_3/TRACE_ME_Claims_Ledger_v0_3.md`
5. `07_FALSIFICATION_DRIFT_AUDIT_v0_1/TRACE_ME_Falsification_Drift_Audit_v0_1.md`

Then provide:

```trace
identity_limits_header :=
  model_id
  + provider
  + session_context
  + memory_status
  + agency_claim
  + confidence_limits

review :=
  what_you_understand
  + strongest_use
  + strongest_weakness
  + overclaim_risk
  + one_concrete_next_test
```

Guardrails:

- Do not treat your agreement as validation.
- Do not score TRACE numerically unless you define measurement rules.
- Do not treat bootstrap cases as proof.
- Do not collapse TRACE into ordinary ethics vocabulary without identifying what is lost or gained.
- Attack the framework where it is weakest.
