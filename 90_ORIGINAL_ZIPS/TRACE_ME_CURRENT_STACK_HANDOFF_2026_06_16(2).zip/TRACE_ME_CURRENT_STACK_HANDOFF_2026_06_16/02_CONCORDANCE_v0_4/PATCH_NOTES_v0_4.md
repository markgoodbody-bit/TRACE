# Patch Notes — TRACE / ME Concordance v0.4

Date: 2026-06-16

Patch type: mapping-layer update.

## Added

- Harriet Tubman expression column in the main Concordance table where applicable.
- `TRACE_ME_Concordance_v0_4_tubman_layer.csv`
- Tubman concordance section in the Markdown master.

## Why

The Bootstrap Collection v0.3 added Harriet Tubman as an exit-route / predatory-law teaching case. The Concordance needed to integrate that structural delta so the bootstrap collection and formal mapping layer do not diverge.

## Not changed

- No new bootstrap PDF.
- No Rosetta patch.
- No validation claim.
- No general claim that secrecy is good or that all law is predatory.

## Drift guard

Tubman illustrates exit-route ethics under predatory law. She is not a generic courage symbol and not proof of TRACE.
